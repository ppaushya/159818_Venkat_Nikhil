package org.cap.demo;

public class Helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         System.out.println("hello world");
	}

}
