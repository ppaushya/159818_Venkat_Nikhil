package org.cap.demo;

public class Mainclass {

	public static void main(String[] args) {
		Simpleinterest interest=new Simpleinterest();
		
		interest.getData();
		
		double simpleInter = interest.calculateInterest();
		
		System.out.println("calculates interest is"+ " " + simpleInter);

	}

}
