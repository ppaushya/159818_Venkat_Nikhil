package org.cap.demo;

import java.util.*;

public class Simpleinterest {

	double principle;
	float years;
	float rateOfInterest;
	
	public void getData()
	{
		/*
		principle=4000;
		years=3.3f;
		rateOfInterest=0.0665f;
		*/
		
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("enter principle");
			
			principle=scanner.nextDouble();
			
System.out.println("enter years");
			
			years=scanner.nextFloat();
			
System.out.println("enter rate of interest");
			
			rateOfInterest=scanner.nextFloat();
		
		
		scanner.close();
		
	}
	
	public double calculateInterest()
	{
		return (principle*years*rateOfInterest);
	}
	
	

}
