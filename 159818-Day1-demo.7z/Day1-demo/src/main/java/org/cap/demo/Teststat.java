package org.cap.demo;

public class Teststat {
    
	String name;
	static int count;
	
	
	public void show()
	{
		System.out.println("name" + name);
		System.out.println("count" + count);
	}
	
	public static void main(String[] args) {
		
		
		Teststat obj=new Teststat();
		obj.name="Tom";
		obj.count=10;
		obj.show();
		System.out.println("name" + obj.name);
		System.out.println("count" + obj.count);
		
		
		Teststat obj1=new Teststat();
		obj1.name="Jerry";
		obj1.count=900;
		obj1.show();
		System.out.println("name" + obj1.name);
		System.out.println("count" + obj1.count);
		
		
		System.out.println(obj.name + " " + obj.count);
		
	}

}
