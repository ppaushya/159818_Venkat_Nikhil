package org.cap.demo;

import java.util.*;

public class employee {

	int empId;
	String empName;
	int age;
	boolean isPermanent;
	String gender;
	String address;
	
	public void getEmployee()
	{
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter employee id");
			
		empId= scanner.nextInt();
		
		System.out.println("Enter employee name");
		
		empName= scanner.next();
		
		System.out.println("Enter employee age");
		
		age= scanner.nextInt();
		
		System.out.println("Enter employee position");
		
		isPermanent= scanner.nextBoolean();
		
		System.out.println("Enter employee gender");
		
		gender= scanner.next();
		
System.out.println("Enter employee address");
		
		address= scanner.next();
		
		
	}
	
	public void printEmployee()
	{
		 System.out.println("employee id is "+empId);
		 System.out.println("employee name is "+empName);
		 System.out.println("employee age is "+age);
		 System.out.println("employee permanent? "+isPermanent);
		 System.out.println("employee gender is "+gender);
		 System.out.println("employee address is "+address);
	}
	
	
	public static void main(String[] args) {
		
		employee emp=new employee();
		emp.getEmployee();
		emp.printEmployee();	

	}

}
