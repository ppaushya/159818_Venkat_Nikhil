package org.cap.demo;

public class test {

	int a;
	char b;
	boolean c;
	long d;
	
	
	public static void main(String[] args) {
		
		test t=new test();
		System.out.println(t.a);
		System.out.println(t.b);
		System.out.println(t.c);
		System.out.println(t.d);
	}

}
