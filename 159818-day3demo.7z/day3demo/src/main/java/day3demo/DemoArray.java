package day3demo;

import java.util.*;

public class DemoArray {

	int myArr[];
	
	public void getElements()
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter size");
		
		
		int size=sc.nextInt();
		
		System.out.println("enter "+size+" arary elements");
		
		int i;
		
		myArr=new int[size];
		
		for(i=0;i<size;i++)
		{
			myArr[i]=sc.nextInt();
		}
		sc.close();
	}
	
	public void printelements()
	{
		for(int i=0;i<myArr.length;i++)
		{
			System.out.println(myArr[i]);
		}
	}
	
	
	public void printreversearray()
	{
		int i;
		
		for(i=myArr.length-1;i>=0;i--)
		{
			System.out.println(myArr[i]);
		}
	}
	
	public void reversearray()
	{
		int start=0;
		int end=(myArr.length)-1;
		
		int i,mid,temp;
		
		while(start<end)
		{
			temp=myArr[start];
			myArr[start]=myArr[end];
			myArr[end]=temp;
			start++;
			end--;
		}
		
		
	}
	
	
	public void sortarray()
	{
		
		//bubble sort
		int i,j,temp,end=myArr.length;
		
		for(i=0;i<end;i++)
		{
			for(j=i+1;j<end;j++)
			{
				if(myArr[i]>myArr[j])
				{
					temp=myArr[i];
					myArr[i]=myArr[j];
				   myArr[j]=temp;
				}
			}
		}
	}
	
	
	public void findbiggest()
	{
		int end=myArr.length;
		
		int i;
		
		int max=myArr[0];
		
		for(i=1;i<end;i++)
		{
			if(max<myArr[i])
			{
				max=myArr[i];
			}
		}
		
		System.out.println("biggest element is "+max);
	}
	
	public void findsmallest()
	{
		int end=myArr.length;
		
		int i;
		
		int min=myArr[0];
		
		for(i=1;i<end;i++)
		{
			if(min>myArr[i])
			{
				min=myArr[i];
			}
		}
		
		System.out.println("smallest element is "+min);
	}
	
	
	public void evennumbers()
	{
		int end=myArr.length;
		
		int sum=0,i;
		
		for(i=0;i<end;i++)
		{
			if(myArr[i]%2==0)
			{
				System.out.println(myArr[i]);
				sum+=myArr[i];
			}
		}
		
		System.out.println("the sum of even numbers is "+sum);
	}
	
	
	public void findsmallestnum(int[] myArr)
	{
		int i,j;
		
		int flag=0;
		
		int end=myArr.length;
		
		
		for(i=0;i<end-1;i++)
		{
			if(myArr[i+1]-myArr[i]>1)
			{
				System.out.println(myArr[i]+1);
				flag=1;
				break;
				
			}
		}
		
		if(flag==0)
		{
			System.out.println(myArr[end-1]+1);
		}
		
	}
	
	public static void main(String[] args) {
		
		DemoArray obj=new DemoArray();
		
		//System.out.println(obj.myArr);
				
		obj.getElements();
		
		//obj.printelements();
		
       //obj.printreversearray();
       
   //    obj.reversearray();
       
       //obj.printelements();
		
       obj.sortarray();
       
   //    System.out.println("after sorting the elements");
       
    //   obj.printelements();
		
       
       obj.findsmallestnum(obj.myArr);
       //obj.findbiggest();
       
       //obj.findsmallest();
       
       //obj.evennumbers();
	}

}
