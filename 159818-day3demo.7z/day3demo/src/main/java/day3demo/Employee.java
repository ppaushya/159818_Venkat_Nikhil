package day3demo;

import java.util.*;

public class Employee {

	String firstName;
	String lastName;
	int age,salary,id;
	
	Scanner sc=new Scanner(System.in);
	
	public void getEmployeedetails()
	{
		
		
		System.out.println("enter the first name of the employee");
		
		firstName=sc.next();
		
		
		System.out.println("enter the last name of the employee");
		
		lastName=sc.next();
		
		
		System.out.println("enter the id of the employee");
		
		id=sc.nextInt();
		
		System.out.println("enter the age of the employee");
		
		age=sc.nextInt();
		
		
		
		System.out.println("enter the salry of the employee");
		
		salary=sc.nextInt();
		
		
	}
	
	
	public void printemployees()
	{
		System.out.println("first name is " + firstName);
		System.out.println("last name is "+lastName);
		System.out.println("id is "+id);
		System.out.println("age is "+age);
		System.out.println("salary is "+salary);
	}
	
	
	
	public static void main(String[] args) {
		
		Employee obj[]=new Employee[5];
		Employee temp=new Employee();
		
		int i;
		
		for (i=0;i<3;i++)
		{
			obj[i]=new Employee();
			obj[i].getEmployeedetails();
		}
		for (i=0;i<3;i++)
		{
			obj[i].printemployees();
		}
		
		
		
		
		int j;
		for(i=0;i<3;i++)
		{
			for(j=i+1;j<3;j++)
			{
				if(obj[i].id>obj[j].id)
				{
					temp=obj[i];
					obj[i]=obj[j];
					obj[j]=temp;
				}
			}
		}
		
		
		for(i=0;i<3;i++)
		{
			obj[i].printemployees();
		}
		
		
	}

}
