package day3demo;

public class TestArray {

	public static void main(String[] args) {
		
		
		//int[] num=new int[10];
		
		int num[]= {1,2,3,4,5};
		
		short mynum=90;
		
		double pi=(int)3.14;
		
		System.out.print(num.length);
		
		
	/*	num[0]=1;
		num[1]=mynum;
		num[2]=45;
		num[3]=(int)pi;
		*/
		//System.out.println(num);
		
		for(int i=0;i<num.length;i++)
		{
			System.out.println(num[i]);
		}
		
	}

}
