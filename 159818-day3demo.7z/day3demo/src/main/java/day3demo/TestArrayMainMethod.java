package day3demo;

public class TestArrayMainMethod {

	public void printdata(int ...x)
	{
		for(int t : x)
		{
			System.out.println(t);
		}
	}
	
	
	public static void main(String[] args) {
	
		int nums[]= {1,2,3,4,5};
		
		TestArrayMainMethod t=new TestArrayMainMethod();
		
		t.printdata(nums);
		
		
	}

}
