package day3demo;

public class findminarrays {

	public void sortarray(int c[][])
	{
		int i,j,k,temp;
		
		int d[][]=new int[c.length][c[0].length];
		
		for(k=0;k<c.length;k++)
		{
			for(i=0;i<c[0].length;i++)
			{
				for(j=i+1;j<c[0].length;j++)
				{
					if(c[k][i]>c[k][j])
					{
						temp=c[k][i];
						c[k][i]=c[k][j];
						c[k][j]=temp;
					}
				}
			}
		}
		
		
		
		
	}
	
	
	public void findsmallest(int t[][])
	{
		
		int rows=t.length;
		
		int cols=t[0].length;
		
		int i,j,flag=0;
		
		sortarray(t);
		
		for(i=0;i<t.length;i++)
		{
			
			for(j=0;j<t[0].length-1;j++)
			{
				if(t[i][j+1]-t[i][j]>1)
				{
					System.out.println(t[i][j]+1);
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(t[i][cols-1]+1);
			}
			flag=0;
		}
		
		
	}
	
	
	public static void main(String[] args) {
	
		int a[][]= {{10,20,30},{1,7,8},{100,1,0}};
		
		findminarrays obj=new findminarrays();
		
		obj.findsmallest(a);
		
	
	}

}
