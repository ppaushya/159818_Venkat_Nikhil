package day3demo;

public class matrixaddmult {

	public void findadd(int a[][],int b[][])
	{
		int c[][]=new int[a.length][a[0].length];
		
		int i,j;
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a[0].length;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
			}
		}
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a[0].length;j++)
			{
			  System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
	}
	public void findmul(int a[][],int b[][])
	{
		int c[][]=new int[a.length][a[0].length];
		
		int i,j;
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a[0].length;j++)
			{
				c[i][j]=a[i][j]* b[i][j];
			}
		}
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a[0].length;j++)
			{
			  System.out.print(c[i][j]+" ");
			}
			System.out.println();
		}
		
	}
	
	public static void main(String[] args) {
		
		int a[][]= {{1,2},{3,4}};
		
		int b[][]= {{1,2},{3,4}};
		
		matrixaddmult obj=new matrixaddmult();
		
		obj.findadd(a,b);
		obj.findmul(a,b);
	}

}
