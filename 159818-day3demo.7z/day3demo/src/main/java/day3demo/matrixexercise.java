package day3demo;

import java.util.Scanner;




public class matrixexercise {

	public void printmatrix(int[][] t)
	{
		int i,j,k;
		
		for(i=0;i<t[0].length;i++)
		{
			for(j=0;j<=i;j++)
			{
				System.out.print(t[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println();
  
		for(i=0;i<t[0].length;i++)
		{
			for(j=0;j<i;j++)
			{
				System.out.print(" ");
			}
			for(k=0;k<(t[0].length)-i;k++)
			{
				System.out.print(t[i][k+i]);
			}
			
			
			System.out.println();
		}
		
		int temp;
		/*
		for(i=0;i<t[0].length;i++)
		{
			for(j=0;j<t[0].length;j++)
			{
				 temp=t[i][j];
				 t[i][j]=t[j][i];
				 t[j][i]=temp;
			}
		}
		*/
		for(i=0;i<t[0].length;i++)
		{
			for(j=0;j<t[0].length;j++)
			{
				System.out.print(t[j][i]+" ");
			}
			System.out.println();
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		
		int n=sc.nextInt();
		
         int a[][]=new int[n][n];
         
         int i,j,k;
         
         for(i=0;i<n;i++)
         {
        	 for(j=0;j<n;j++)
        	 {
        		 a[i][j]=sc.nextInt();
        	 }
         }
         
         matrixexercise obj=new matrixexercise();
         
         obj.printmatrix(a);
         
         sc.close();
         
	}

}
