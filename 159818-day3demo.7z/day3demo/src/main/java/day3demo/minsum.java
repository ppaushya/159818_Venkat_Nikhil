package day3demo;

public class minsum {

	public void findmin(int t[][])
	{
		int sum[]=new int[t.length];
		
        int i,j,k;
        
        
        for(i=0;i<t.length;i++)
        {
        	for(j=0;j<t[0].length;j++)
        	{
        		sum[i]=sum[i]+t[i][j];
        	}
        }
		
		
		for(i=0;i<t.length;i++)
		{
			System.out.println(sum[i]);
		}
        
		
		
	}
	
	public static void main(String[] args) {
	
		int a[][]= {{1,2},{0,1},{-1,1}};
		
		minsum obj=new minsum();
		
		obj.findmin(a);
		
	}

}
