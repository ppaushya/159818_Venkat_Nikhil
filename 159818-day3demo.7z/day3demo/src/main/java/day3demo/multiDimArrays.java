package day3demo;

import java.util.Scanner;

public class multiDimArrays {

	
	public static void main(String[] args) {
		/*
	 int[][] arr=new int[3][2];
	 
	 arr[0][0]=12;
	 arr[0][1]=34;
	 
	 arr[1][0]=90;
	 arr[1][1]=78;
	 
	 arr[2][0]=11;
	 arr[2][1]=55;
	 
	 */
		Scanner sc=new Scanner(System.in);
		
		int arr[][]=new int[3][2];
		
	 int i,j;
	 
	 for(i=0;i<3;i++)
	 {
		 for(j=0;j<2;j++)
		 {
			 arr[i][j]=sc.nextInt();
		 }
	 }
	 
	 
	 for(i=0;i<3;i++)
	 {
		 for(j=0;j<2;j++)
		 {
			 System.out.println(arr[i][j]);
		 }
	 }
	 
	 
	}

}
