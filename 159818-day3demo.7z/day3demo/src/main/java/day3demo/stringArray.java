package day3demo;

import java.util.Scanner;

public class stringArray {
   
	String[] mystr;
	
	public void acceptString()
	{
		int size;
		Scanner s=new Scanner(System.in);
		size=s.nextInt();
		
		mystr=new String[size];
		
		int i;
		
		for(i=0;i<size;i++)
		{
			System.out.println("enter the string");
			mystr[i]=s.next();
		}
		
		
		
	}
	
	
	public void reversestrarray()
	{
		 String temp;
		
		 int start=0;
		 int end=mystr.length-1;
		 
		 
		 
		 int i;
		 
		 while(start<end)
		 {
			 temp=mystr[start];
			 mystr[start]=mystr[end];
			 mystr[end]=temp;
			 start++;
			 end--;
		 }
		
	}
	
	public void printelements()
	{
		int size=mystr.length;
		int i;
		for(i=0;i<size;i++)
		{
			System.out.println(mystr[i]);
		}
	}
	
	
	public void sortstrarray()
	{
		int i,j;
		
		String temp,part;
		
		int end=mystr.length;
		
		for(i=0;i<end;i++)
		{
			for(j=i+1;j<end;j++)
			{
				
				if(mystr[i].compareTo(mystr[j])==1)
				{
					temp=mystr[i];
					mystr[i]=mystr[j];
					mystr[j]=temp;
					
				}
			}
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
            
		stringArray obj=new stringArray();
		
		obj.acceptString();
		
		obj.printelements();
		
		//obj.reversestrarray();
	
		//obj.printelements();
		
		obj.sortstrarray();
		
		obj.printelements();
		
	}

}
