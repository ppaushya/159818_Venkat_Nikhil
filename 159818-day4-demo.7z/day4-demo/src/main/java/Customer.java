
 enum customertype
{
	SILVER(0,100),GOLD(100,200),DIAMOND(200,300),PLATINUM(300,400);
	 
	 int minrewardpoints,maxrewardpoints;
	  
	 private customertype(int minrewardpoints,int maxrewardpoints)
	 {
		 this.minrewardpoints=minrewardpoints;
		 this.maxrewardpoints=maxrewardpoints;
	 }
	 
	 public int getminrewardpoints()
	 {
		 return this.minrewardpoints;
	 }
	 
	 public int getmaxrewardpoints()
	 {
		 return this.maxrewardpoints;
	 }
	 
	 
}



public class Customer {
	
	int custid=100;
	String custname="nikhil";
	customertype  custtype=customertype.DIAMOND;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Customer cust=new Customer();
		
		System.out.println(cust.custid +" "+ cust.custname
	+" "+cust.custtype+" "+"range is "+cust.custtype.getminrewardpoints()+
	"-"+cust.custtype.getmaxrewardpoints());;

	}

}
