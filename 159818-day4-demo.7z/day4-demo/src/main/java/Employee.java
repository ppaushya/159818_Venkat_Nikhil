
import java.util.*;

public class Employee {

	int empid;
	String firstname;
	String lastname;
	int age,salary;
	Weekdays weekOff;
	
	public void getEmployee()
	{
		
		Scanner s=new Scanner(System.in);
		
        empid=s.nextInt();
        
        firstname=s.next();
        
		lastname=s.next();
		age=s.nextInt();
		salary=s.nextInt();
		
		int temp=s.nextInt();
		
		if(temp==1)
		{
			weekOff= Weekdays.MON;	
		}
		else if(temp==2)
		{
			weekOff= Weekdays.TUES;		
		}
		
		else if(temp==3)
		{
			weekOff= Weekdays.WED;		
		}
		else if(temp==4)
		{
			weekOff= Weekdays.THURS;		
		}
		else if(temp==5)
		{
			weekOff= Weekdays.FRI;		
		}
		else if(temp==6)
		{
			weekOff= Weekdays.SAT;		
		}
		else if(temp==7)
		{
			weekOff= Weekdays.SUN;		
		}
	}
	
	public void printemployee()
	{
		System.out.println(empid+" "+firstname+" "+lastname+" "+age+" "
	+salary+" "+weekOff.getvalue()+" "+weekOff);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp=new Employee();
		
		emp.getEmployee();
		
		emp.printemployee();
		
	}

}
