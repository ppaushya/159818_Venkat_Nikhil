
public class Product {

	int prodid;
	String prodbname;
	double price;
	int quantity;
	
	
	
	  public Product()
	  {
		  System.out.println("default constructor");
		  
		  
	  }
	
  public Product(int a)
  {
	  this.prodid=100;
	  System.out.println("overload  constructor with 1 parameter");
  }
	
  public Product(int a,String b,double p,int quan)
  {   
	  this.prodid=a;
	  this.prodbname=b;
	  this.price=p;
	  this.quantity=quan;
	  System.out.println("overload  constructor with all parameter");
  }


@Override
public String toString() {
	return "Product [prodid=" + prodid + ", prodbname=" + prodbname + ", price=" + price + ", quantity=" + quantity
			+ "]";
}

public void printdetails()
  {
	  System.out.println(prodid+" "+prodbname+" "+price+" "+quantity);
  }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product tt=new Product();
		

		Product st=new Product();
		System.out.println(tt);
		
		
		Product t = new Product(100);
		
		t.printdetails();
		
		//it will call default constructor 
		
		
Product ttt = new Product(100,"nikhil",100,100);
		
		ttt.printdetails();
		
		
	}

}
