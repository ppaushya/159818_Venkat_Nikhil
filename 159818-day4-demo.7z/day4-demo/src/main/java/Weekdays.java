
public enum Weekdays {

	SUN(1),MON(2),TUES(3),WED(4),THURS(5),FRI(6),SAT(7);
		
	
//
	//Weekdays w=new Weekdays();
	
	int value;
	
	private Weekdays(int var)
	{
		this.value=var;
	}
	
	public int getvalue()
	{
		return this.value;
		}
	
	
}
