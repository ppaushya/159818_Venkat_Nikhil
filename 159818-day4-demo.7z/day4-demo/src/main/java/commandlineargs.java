
public class commandlineargs {

	public static void main(String[] args) {
      
		int num,sum=0;
    
		if(args.length>0)
		{
			for(String str : args)
			{
			   System.out.println(str);
			   
			   num=Integer.parseInt(str);
			   
			   sum+=num;
			   
			}
		}
		
		System.out.println(sum);
		
	}

}
