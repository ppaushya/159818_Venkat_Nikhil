import java.util.*;


public class day4exercises {

	public int prime(int n)
	{
		int i,j,count=0;
		
		for(i=2;i<n;i++)
		{
			if(n%i==0)
			{
				count++;
			}
		}
		if(count==0)
		{
			return 0;
		}
		else
		{
			return 1;
		}
		
	}
	
	
	public static void main(String[] args) {
		
		//problem 1 - prime fraction of a number
		
		//like 6 =2,3 and 24 = 2,2,2,3
		
		
		Scanner s =new Scanner(System.in);
		
		int num=s.nextInt();
		
		day4exercises obj=new day4exercises();
		
		int i=2;
		
		while(i<=num)
		{
			if(obj.prime(i)==0)
			{
				while(num%i==0)
				{
				   System.out.println(i);
				   num=num/i;
				}
					
			}
			i++;
		}
		
		
	
	

	}

}
