//nested enums is  not possible..so we cant create nested enums
