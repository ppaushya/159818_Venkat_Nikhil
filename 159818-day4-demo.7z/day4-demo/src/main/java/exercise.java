
public class exercise {

	public static void main(String[] args) {
		
		
		String str="nikhil",str2="NIKHILvenkat";
		
		char str3[]= {'n','s','p'};
		
		//using char at -- returns character
		System.out.println(str.charAt(3));
		
		//codepoint at - returns the unicode at specified index
		
		System.out.println(str.codePointAt(3));
		
		//comapreTo - returns int
		
		System.out.println(str.compareTo(str2));
		
		System.out.println(str.compareToIgnoreCase(str2));
		
		System.out.println(str.concat(str2));
		
		System.out.println(str.contains(str2));
		
		System.out.println(str.contentEquals(str2));
		
		System.out.println(str.copyValueOf(str3));
		
		
	}

}
