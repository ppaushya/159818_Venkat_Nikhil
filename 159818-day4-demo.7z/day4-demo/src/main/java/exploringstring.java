
public class exploringstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
		
		String str="nikkkhil";
		
		String mystr=new String("nikhIl");
		
		System.out.println(str.hashCode()+" "+mystr.hashCode());
		
       String myname="nikhil";
       
   	System.out.print(myname.hashCode()+" ");
       
   	String mysr=new String("nikhil");
   	
   	System.out.println(mysr.hashCode());
   	
   	System.out.println(str.equalsIgnoreCase(mystr));
	
   	System.out.println(str.indexOf('k',3));
   	
   	System.out.println(str.indexOf("nik"));
   	
   	
   	System.out.println(str.replace('k', 'a'));
   	
   	System.out.println(str.toLowerCase());
   	
   	System.out.println(str.valueOf('k'));
   	
	}

}



