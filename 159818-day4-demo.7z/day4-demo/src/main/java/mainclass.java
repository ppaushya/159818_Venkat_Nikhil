
public class mainclass {

	public static void main(String[] args) {
      
		Weekdays myday=Weekdays.MON;

		switch(myday)
		{
		case SUN :
			System.out.println("holiday");
			break;
		case SAT :
			System.out.println("weekoff :) ");
			break;
		default :
			System.out.println("working days");
			break;
		}
		
		
	}

}
