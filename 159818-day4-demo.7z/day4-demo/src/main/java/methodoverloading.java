
public class methodoverloading {

	int principle;
	int rateOfinterest;
	int years;
	
	public methodoverloading(int p,int r,int y)
	{
		this.principle=p;
		this.rateOfinterest=r;
		this.years=y;
	}
	

	public methodoverloading(int r,int y)
	{
		this.rateOfinterest=r;
		this.years=y;
	}

	public methodoverloading(int y)
	{
		this.years=y;
	}
	

	public methodoverloading()
	{
		
	}
	
	public void calculatesimple()
	{
		System.out.println("simple interest is "+ (principle * rateOfinterest * years));
	}
	

	public void calculatesimple(int p)
	{
		System.out.println("simple interest is "+ (p  * rateOfinterest * years));
	}
	
	public void calculatesimple(int p,int r)
	{
		System.out.println("simple interest is "+ (p  * r * years));
	}
	
	public void calculatesimple(int p,int t,int r)
	{
		System.out.println("simple interest is "+ (p  * r * t));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		methodoverloading obj=new methodoverloading(1000,10,10);
		
		obj.calculatesimple();
		
		methodoverloading ob=new methodoverloading(1000,10);
		
		ob.calculatesimple(1000);
		
		
		methodoverloading o=new methodoverloading(1000);
		
		o.calculatesimple(10,10);
		

		methodoverloading oo=new methodoverloading();
		
		oo.calculatesimple(1000,10,10);
	}

}
