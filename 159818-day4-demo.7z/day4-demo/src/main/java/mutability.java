
public class mutability {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        String str="tom";
        String mystr=new String("tom");
        String mystr2=new String("tom");
        
        String str1="tom";
        
        
        System.out.println(str==mystr);
        System.out.println(str.equals(mystr));
        

        System.out.println(str==str1);
        System.out.println(str.equals(str1));
	
        System.out.println(mystr==mystr2);
        System.out.println(mystr.equals(mystr2));
	
	}

}
