package org.demo.validate;

public class validation {

	public int count=100;
	public static int num=1001;
	
	public void demo()
			{
				System.out.println(num+count);
			}
	
    public static void show()
    {
    	System.out.println(num);	
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(num);
		
		validation v = new validation();
		v.demo();
		
	}

}
