package org.nikhil.com;

import static org.demo.validate.validation.*;

public class tetsclass {

	public static void main(String[] args) {
		
		show();
		
		System.out.println(num);
		
	}

}
