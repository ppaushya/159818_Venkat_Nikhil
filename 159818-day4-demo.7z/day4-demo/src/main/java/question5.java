import java.util.Scanner;

public class question5
{
    
    public void reversestring(String str)
    {
        char temp[]=new char[str.length()];
        
        int i,j,k;
        
        for(i=0;i<str.length();i++)
        {
            temp[i]=str.charAt(i);
        }
        
        int start=0;
        int end=str.length()-1;
        
        char flag;
        
        while(start<end)
        {
            flag=temp[start];
            temp[start]=temp[end];
            temp[end]=flag;
            start++;
            end--;
        }
        
        
        for(i=0;i<str.length();i++)
        {
            System.out.print(temp[i]);
        }
        
       
    }
    
    
    public static void main(String[] args)
    {
     
     Scanner s=new Scanner(System.in);
     
     String str;
     
     str=s.nextLine();
     
    question5 obj=new question5();
     
    obj.reversestring(str);
     
    
        
    }
}