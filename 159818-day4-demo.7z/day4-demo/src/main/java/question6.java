import java.util.Scanner;
public class question6 {
public int findFactorial(int num)
{
if(num==1)
{
return 1;
}
return num*findFactorial(num-1);
}

public static void main(String[] args) {
// TODO Auto-generated method stub
Scanner scr=new Scanner(System.in);
System.out.println("Enter the number");
int num=scr.nextInt();
question6 f=new question6();
int result=f.findFactorial(num);
System.out.println(result);
}

}