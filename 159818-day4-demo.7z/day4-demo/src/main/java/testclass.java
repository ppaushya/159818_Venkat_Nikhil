
import java.util.*;

public class testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           int arr[]= {1,2,4,3,12,8};
           
           /*
           String a[]= {"nikhil","venkat","marabathula"};
           
           Arrays.sort(a);
           
           
           int i;
           
           for(i=0;i<3;i++)
           {
        	   System.out.println(a[i]);
           }
     
           int myarr[]=Arrays.copyOf(arr, 3);
           

           for(i=0;i<3;i++)
           {
        	   System.out.println(myarr[i]);
           }
           
           myarr[0]=100;
           
           for(i=0;i<3;i++)
           {
        	   System.out.println(myarr[i]);
           }
           for(i=0;i<3;i++)
           {
        	   System.out.println(arr[i]);
           }
           
           //both the arrays pointing to different locations
           
           
           myarr=Arrays.copyOfRange(arr, 1,arr.length);
           
           */
           
           //do binary search
           
           Arrays.sort(arr);

           for(int i=0;i<arr.length;i++)
           {
        	   System.out.println(arr[i]);
           }
           

          int start=0;
          int end=arr.length-1;
          int mid;
          
          int num=13;
          
          int flag=1;
          
          while(start>=end)
          {
        	  
        	  mid=(start+end)/2;
        	  
        	  if(num>arr[mid])
        	  {
        		  start=mid+1;
        	  }
        	  else if(num==arr[mid])
        	  {
        		  System.out.println("found");
        	      flag=0;
        		  break;
        	  }
        	  else
        	  {
        		  end=mid-1;
        	  }
          }
          
          if(flag==1)
          {
          System.out.println("not found");
          }
	}

}
