
public class testclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Weekdays week[]=Weekdays.values();
		
		for(Weekdays day : week)
		{
			System.out.println(day);
  		}
	  
		String str="SAT";
		
		Weekdays myday= Weekdays.valueOf(Weekdays.class,str);
		
		//if str doesnt match with the value in weekdays enum then it throws a exception illegalargument exception
		
		System.out.println(myday);
		
	}

}
