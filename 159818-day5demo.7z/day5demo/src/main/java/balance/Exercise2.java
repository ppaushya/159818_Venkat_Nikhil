package balance;

interface inter1
{
	void print();
	
	int num=100; //here the default type is public static final, we have to initialise else an error throws 
	
}

public class Exercise2 implements inter1{

	@Override
	
	public void print()
	{
		System.out.println(num);
		System.out.println("implementing interface");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Exercise2 obj=new Exercise2();
		
		obj.print();
		
		System.out.println(num); //as num type is public static final instead of creating an referring an objcet we can directly access but we cant modify it
		

	}

}
