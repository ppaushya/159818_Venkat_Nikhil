package balance;

import java.util.Scanner;

interface inter2
{
	void division();
	void modulus();
}




public class exercise3 implements inter2{
   
	int a,b;
	
	public void division()
	{
		Scanner s = new Scanner(System.in);
		
		a=s.nextInt();
		
		b=s.nextInt();
		
		System.out.println("division of "+a+" and "+b+" "+"is "+(a/b));
		
	}
	
	public void modulus()
	{
		System.out.println("modulus of "+a+" and "+b+" "+"is "+(a%b));
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
exercise3 obj=new exercise3();
obj.division();
obj.modulus();
		
		
	}

}
