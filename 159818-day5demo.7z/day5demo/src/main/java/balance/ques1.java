package balance;

public class ques1 extends Account{

	
	
	public static void main(String[] args)
	{
	   ques1 obj=new ques1();
	   
	   obj.displayBalance();
	   
	}
}
