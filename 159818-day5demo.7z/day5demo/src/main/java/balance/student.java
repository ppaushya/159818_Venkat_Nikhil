package balance;

public interface student {

	void display_grade();
	void attendance();

	
}
