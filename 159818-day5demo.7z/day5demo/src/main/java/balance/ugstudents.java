package balance;

import java.util.Scanner;

public class ugstudents implements student {
    
	float marks,attend;
	
	public void display_grade()
	{
		Scanner s = new Scanner(System.in);
		
		marks=s.nextFloat();
		
		if(marks>=80)
		{
			System.out.println("passed");
		}
		else
		{
			System.out.println("failed");
		}
		
	}
	
	

	public void attendance()
	{
		Scanner s = new Scanner(System.in);
		
		attend=s.nextFloat();
		
		if(attend>=80)
		{
			System.out.println("regular");
		}
		else
		{
			System.out.println("irregular");
		}
		
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ugstudents obj=new ugstudents();
		
		
		obj.display_grade();
		
		obj.attendance();
		
		
	}

}
