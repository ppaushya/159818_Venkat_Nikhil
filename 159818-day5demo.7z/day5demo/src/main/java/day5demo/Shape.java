package day5demo;

public abstract class Shape {

	int width;
	int height;
	
	public Shape()
	{
		System.out.println("shape class no arg constructor");
	}
	
	public Shape(int height,int width)
	{
		this.height=height;
		this.width=width;
		System.out.println("shape class no arg constructor");
	}
	
	public void info()
	{
		System.out.println("shape information");
	}
	
	public abstract void draw();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
