package day5demo;

public class Student {

	private int studid;
	
	private String firstname,lastname;
	
	private double regfee;

	public Student()
	{
		
	}
	
	public Student(int studid, String firstname, String lastname, double regfee) {
		super();
		this.studid = studid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.regfee = regfee;
	}

	public int getStudid() {
		return studid;
	}



	public void setStudid(int studid) {
		this.studid = studid;
	}



	public String getFirstname() {
		return firstname;
	}



	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}



	public String getLastname() {
		return lastname;
	}



	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	public double getRegfee() {
		return regfee;
	}



	public void setRegfee(double regfee) {
		this.regfee = regfee;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		
		Student s=new Student();
		
		
		
	}

}
