package day5demo;

public abstract class Worker {

	String name;
	
	public Worker()
	{
		
	}
	
	public Worker(String name) {
		//super();
		this.name = name;
	}



	public abstract float compay();
	
	
}
