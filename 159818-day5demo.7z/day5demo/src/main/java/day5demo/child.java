package day5demo;

public class child extends parent {

	int num=700;

	public void show()
	{
		super.show();
		System.out.println(num);
	}
	

	public child()
	{
		System.out.println("child  constructor");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
	}

}
