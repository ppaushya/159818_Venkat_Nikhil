package day5demo;

public class circle extends Shape {

	float radius=10;
		
	final float PI=3.14f;
	
	
	public circle()
	{
	  System.out.println("circle class no argument constructor");	
	}
	
	public circle(float rad)
	{
		this.radius=rad;
		 System.out.println("circle class full argument constructor");	
	}
	
	public void draw()
	{
		System.out.println("circle class draw method");
	}
	
	public float calculatearea()
	{
		return PI * radius * radius;
	}
	
	
	
}
