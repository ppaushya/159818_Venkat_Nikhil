package day5demo;

public class circles implements shapes,traingle {


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void draw() {
		shapes.show();
		System.out.println("draw method of circle");
	}

	
	
	
	@Override
	public void info() {
		showpoints();
		System.out.println("info method of circle");
		
	}

	@Override
	public void fillcolor() {
		System.out.println("i have filled color");
		
	}

	@Override
	public void filllinecolor() {
		// TODO Auto-generated method stub
		System.out.println("i have filled line color");
	}

	@Override
	public void showpoints() {
		
		shapes.super.showpoints();
		
		System.out.println("i have overridden");
	}

	
	
	
	
}
