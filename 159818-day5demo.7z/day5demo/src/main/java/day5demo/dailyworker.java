package day5demo;

import java.util.Scanner;

public class dailyworker extends Worker{

	float days;
	
	

	
	public float compay()
	{
		Scanner s = new Scanner(System.in);
	   	
		days=s.nextFloat();
		
		return days * 100;
		
	}
	
	
	public dailyworker(String name)
	{
		super(name);
	}
	
}
