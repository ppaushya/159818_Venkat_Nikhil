package day5demo;

import java.util.*;

public class employee extends person{

	double salary;
	boolean ispermanent;
	
	public void getemployee()
	{
		Scanner s =new Scanner(System.in);
		
		System.out.println("enter salary and permanency");
		
		salary=s.nextDouble();
		
		ispermanent=s.nextBoolean();
		
		show();
		
		super.show();
		
	}
	
	public void showemployee()
	{
		System.out.println(salary + " " + ispermanent+" "+personid+" "+firstname+" "+lastname);
	}
	
	
	public void show()
	{
		  System.out.println("employee class- show method");	
	}
	
	public employee(double salary, boolean ispermanent) {
		//super();
		this.salary = salary;
		this.ispermanent = ispermanent;
	}
	public employee(int empid,String fname,String lname,double salary, boolean ispermanent)
	{
		super(empid,fname,lname);
		this.salary = salary;
		this.ispermanent = ispermanent;
	}
	
	
	public employee()
	{
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


	
		
	}

	
	
}
