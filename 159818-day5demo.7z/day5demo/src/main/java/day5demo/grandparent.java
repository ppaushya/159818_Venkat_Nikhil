package day5demo;

public class grandparent {

	protected int num=1000;

	public grandparent()
	{
		System.out.println("grandparent constructor");
	}
	
	public static void main(String[] args) {
		System.out.println();
		
		System.out.println();
		
	}

}
