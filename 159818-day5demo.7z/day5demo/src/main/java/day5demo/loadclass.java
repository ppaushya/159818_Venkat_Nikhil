package day5demo;

public class loadclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student t= new Student(100,"nikhil","venkat",1000);
		
		System.out.println(t.getFirstname()+" "+t.getLastname()+" "+t.getRegfee()+" "+t.getStudid());
		
	}

}
