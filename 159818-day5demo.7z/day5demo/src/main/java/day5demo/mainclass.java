package day5demo;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		employee e=new employee();
		
		e.getpersondetails();
		
		e.getemployee();
		
		e.showemployee();
		
		
		*/
		
	
	
		
		
    employee emp=new employee();
    employee emp2=new employee(1000,true);
    employee emp3=new employee(100,"nikhil","venkat",1,true);
    
    emp3.getemployee();
    emp3.showemployee();
    
 //   emp3.show();
 		
    

	
	}

}
