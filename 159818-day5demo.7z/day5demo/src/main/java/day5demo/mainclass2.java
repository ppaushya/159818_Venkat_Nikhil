package day5demo;

public class mainclass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  circle c = new circle();
  c.draw();
  //float area=c.calculatearea();
  
	}

}
