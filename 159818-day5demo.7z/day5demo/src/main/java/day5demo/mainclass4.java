package day5demo;

public class mainclass4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		dailyworker d = new dailyworker("nikhil");
		
		System.out.println(d.compay());
		
		salaried s = new salaried("nik");
			
		System.out.println(s.compay());
		
	}

}
