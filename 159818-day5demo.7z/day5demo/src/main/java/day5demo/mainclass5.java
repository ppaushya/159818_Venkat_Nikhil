package day5demo;

public class mainclass5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ordinary obj=new ordinary();
		
		System.out.println(obj.charges());
		
   urgent ob=new urgent();
		
		System.out.println(ob.charges());
		
		
	}

}
