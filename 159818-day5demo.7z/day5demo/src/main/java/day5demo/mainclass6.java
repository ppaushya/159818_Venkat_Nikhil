package day5demo;

public class mainclass6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		circles c = new circles();
		
		c.draw();
		
		c.info();
		
		c.showpoints();
		
		shapes.show();
		
		
		
	}

}
