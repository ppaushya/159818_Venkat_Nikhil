package day5demo;

import java.util.Scanner;

public class ordinary extends trunkcall {

	float mins;
	
	
	
	public ordinary() {
		super();
	}



	public float charges()
	{
		Scanner s = new Scanner(System.in);
		
		mins=s.nextFloat();
		
		return 5 * mins;
	}
	
	
}
