package day5demo;

public class parent extends grandparent{

	
	int num=900;
	
	public parent()
	{
		System.out.println("parent constructor");
	}
	
	public void show()
	{
		//super.show();
		System.out.println(num);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
