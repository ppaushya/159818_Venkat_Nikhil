package day5demo;

import java.util.*;

public class person {

	int personid;
	
	String firstname,lastname;
	
	public person()
	{
		
	}
	
	
	
	public person(int personid, String firstname, String lastname) {
		//super();
		this.personid = personid;
		this.firstname = firstname;
		this.lastname = lastname;
	}


	public void show()
	{
	  System.out.println("person class- show method");	
	}

	public void getpersondetails()
	{
	   Scanner s = new Scanner(System.in);
	   personid=s.nextInt();
	   
	   firstname=s.nextLine();
	   
	   lastname=s.nextLine();
	   
	}
	

	public void showperson()
	{
		System.out.println(personid+" "+firstname+" "+lastname);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
