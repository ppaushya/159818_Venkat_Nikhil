package day5demo;

import java.util.Scanner;

public class salaried extends Worker{

   float hours;
	
   public salaried()
   {
	   
   }
   
   public salaried(String name)
	{
		super(name);
	}
	public float compay()
	{
		Scanner s = new Scanner(System.in);
	   	
		hours=s.nextInt();
		
		if(hours>=40)
		{
		 return  700;
		}
		else
		{
			return 0;
		}
	}
	
}
