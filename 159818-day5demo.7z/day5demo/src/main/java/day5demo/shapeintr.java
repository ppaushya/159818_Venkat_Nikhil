package day5demo;

public class shapeintr {

}
