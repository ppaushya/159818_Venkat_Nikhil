package day5demo;

public interface shapes {

	void draw();
	
	void info();
	
	int num=100;
	
	
	public static void show()
	{
	 details();
	 System.out.println("shape interface show method");
	}
	
	default void showpoints()
	{
		details();
		 System.out.println("shape interface showpoints method");
	}
	
	private static void details()
	{
		 System.out.println("shape interface details method");
	}
	
	
}
