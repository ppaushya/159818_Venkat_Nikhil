package day5demo;

public interface traingle {

	void fillcolor();
	 void filllinecolor();
	
	
	
	
}
