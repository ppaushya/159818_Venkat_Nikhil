package day5demo;

public abstract class trunkcall {

	float charg;

	public abstract float charges();
	
	
}
