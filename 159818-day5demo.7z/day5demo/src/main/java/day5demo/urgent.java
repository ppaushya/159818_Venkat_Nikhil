package day5demo;

import java.util.Scanner;

public class urgent {


	float mins;
	
	public urgent()
	{
		
	}
	
	public float charges()
	{
		Scanner s = new Scanner(System.in);
		
		mins=s.nextFloat();
		
		return 50 * mins;
	}
	
}
