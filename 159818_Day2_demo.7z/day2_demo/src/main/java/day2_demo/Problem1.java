package day2_demo;

import java.util.*;

public class Problem1 {

	String prodName;
	int prodId;
	int quantity;
	float price,discount,tax;
	float finalPrice;
	
	public void getProdDetails()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the name of the product");
		
		prodName=sc.next();
		
System.out.println("Enter the id of the product id");
		
		prodId=sc.nextInt();
		
System.out.println("Enter the quantity");
		
		quantity=sc.nextInt();
		
System.out.println("Enter the price of the product");
		
		price=sc.nextFloat();
		
System.out.println("Enter the discount of the product");
		
		discount=sc.nextFloat();
		

		
		sc.close();
	}
	
	public void calculateTax() {
		
		if(discount>=90)
		{
			tax=1;
		}
		else if(discount>80)
		{
			tax=12;
		}
		else if(discount>70)
		{
			tax=20;
		}
		else if(discount>60)
		{
			tax=25;
		}
		else
		{
			tax=40;
		}
		System.out.println("tax on all is "+price * quantity * (tax/100));
	}
	
	public void calculateDiscount()
	{
		System.out.println("discount on each product is "+ (discount/100) * price);
		System.out.println("discount on all product is "+ (discount/100) * price * quantity);
	}
	
	public void calculateFinalPrice() {
		
		System.out.println( price * quantity + ((tax/100) * price * quantity) - ((discount/100) * price * quantity));
		
	}
	
	public static void main(String[] args) {
		
		Problem1 t=new Problem1();
		
		t.getProdDetails();
		
		t.calculateDiscount();
		
		t.calculateTax();
		
		t.calculateFinalPrice();

	}

}
