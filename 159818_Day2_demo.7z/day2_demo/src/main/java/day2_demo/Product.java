package day2_demo;

import java.util.*;

public class Product {

	String prodName;
	int prodId;
	int quantity;
	float price,discount,tax;
	float finalPrice;
	Scanner sc=new Scanner(System.in);
	
	public void getProdDetails()
	{
		
		
		System.out.println("Enter the name of the product");
		
		prodName=sc.next();
		
System.out.println("Enter the id of the product id");
		
		prodId=sc.nextInt();
		
System.out.println("Enter the quantity");
		
		quantity=sc.nextInt();
		
System.out.println("Enter the price of the product");
		
		price=sc.nextFloat();
		
System.out.println("Enter the discount of the product");
		
		discount=sc.nextFloat();
		

		
		sc.close();
	}
	
	public void calculateTax() {
		
		if(discount>=90)
		{
			tax=1;
		}
		else if(discount>80)
		{
			tax=12;
		}
		else if(discount>70)
		{
			tax=20;
		}
		else if(discount>60)
		{
			tax=25;
		}
		else
		{
			tax=40;
		}
		System.out.println("tax on all is "+price * quantity * (tax/100));
	}
	
	public void calculateDiscount()
	{
		System.out.println("discount on each product is "+ (discount/100) * price);
		System.out.println("discount on all products is "+ (discount/100) * price * quantity);
	}
	
	public void calculateFinalPrice() {
		System.out.println("the final price is");
		System.out.println( price * quantity + ((tax/100) * price * quantity) - ((discount/100) * price * quantity));
		
	}
	
	public static void main(String[] args) {
     int choice;
	  do
	  {
		Product t=new Product();
		
		t.getProdDetails();
		
		t.calculateDiscount();
		
		t.calculateTax();
		
		t.calculateFinalPrice();
	   
		System.out.println("do you want to continue ? [Y/N]");
	    Scanner st=new Scanner(System.in);
	    
		choice = st.nextInt(); 
	  }while(choice==1);
	
	
	}
	
	
	
	

}
