package day2_demo;

public class Switchdemo {

	public static void main(String[] args) {
		
		
		int num=100;
		
		char var='c';
		
		String str="nikhil";
		
		long ln=10000000;
		
		switch(num)
		{
		case 1 :
		case 10:
		case 100 :
		 {
			System.out.print("one");
			System.out.print("block");
			//break;
		  }
		case 2 :
			System.out.print("two");
		    //break;
		      
           default :
			System.out.print("none");
		}
		
		
		
		/*
		
		switch(var)
		{
		case 'a' :
			System.out.println("it is a");
			break;
		case 'c' :
			System.out.println("it is c");
		}
		
		
		
		
		switch(str)
		{
		case "nik" :
			System.out.print("it is nik");
			break;
		case "nikhil" :
		    System.out.println("it is nikhil");
		     break;
		}
		
		
		switch(ln)
		{
		
		case 10000000 :
			System.out.println("it is large no");
			break;
		case 100000000 :
			System.out.println("it is very large number");
			break;
		
		}
		
		*/
		
		
		
		
	}

}
