package day2_demo;

public class Testclass {
	
	
	public void testIf(int num)
	{
		if(num>0)
		{
			System.out.println("Hey! The number is ");
			System.out.println("positive");
			
			if(num%2==0)
			{
				System.out.println("even number");
			}
			else
			{
				System.out.println("odd number");
			}
			
		}
		else if(num==0)
		{
			System.out.println("Hey! The number is ");
			System.out.println("zero");
		}
		
		else 
		{
			System.out.println("Hey! The number is ");
			System.out.println("negative");
		}
	}

	public static void main(String[] args) {
	
		Testclass t=new Testclass();
		t.testIf(100);

		
	}

}
