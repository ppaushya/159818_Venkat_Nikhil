package day2_demo;

public class Testwhile {

	public static void main(String[] args) {
	
		
		int num=10;
		
		while(num>0)
		{
			System.out.println(num);
			num--;
		}
  System.out.println("loop ends and num is 0");
  
      num=10;
      
      do
      {
    	  System.out.println(num);
    	  num--;
      }while(num>0);
	}

}
