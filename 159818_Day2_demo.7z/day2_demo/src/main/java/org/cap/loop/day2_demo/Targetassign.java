package org.cap.loop.day2_demo;

public class Targetassign {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           /*
             
             7.	Write a program to print all possibilities to get the given number as mentioned below:
Given number is 3.
Output:
1+1+1
1+2
2+1

             
            */

		
		int num=6;
		
		int i,j,t=1;
		
	   
		   for(j=t;j<=num;j++)
		   {
			   System.out.println("1");
		   }
		  
	  
		
		
		
		
		
		
	}

}
