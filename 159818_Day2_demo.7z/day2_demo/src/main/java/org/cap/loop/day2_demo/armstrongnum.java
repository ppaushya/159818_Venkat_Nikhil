package org.cap.loop.day2_demo;

public class armstrongnum {

	
	
	public static int cube(int b)
	{
		int rem;
		
	    int summ=0;	
	 
		while(b>0)
		{
			rem=b%10;
			summ=summ+(rem*rem*rem);
			//	System.out.println(rem+" "+summ);
			b=b/10;
		}
		
		return summ;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//4.	Print all Armstrong number between 1 to 1000
		int i,j;
		for(i=1;i<=1000;i++)
		{
			//System.out.print(cube(i));
			if(cube(i)==i)
			{
				System.out.print(i+" ");
			}
		}
		

	}

}
