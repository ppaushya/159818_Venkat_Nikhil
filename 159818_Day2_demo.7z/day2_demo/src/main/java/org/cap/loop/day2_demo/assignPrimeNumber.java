package org.cap.loop.day2_demo;

public class assignPrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//3.	Print all prime numbers between 1 to 1000.
		
		
		int i,count=0,j;
		
		
		for(i=2;i<=1000;i++)
		{
			for(j=2;j<i;j++)
			{
				if(i%j==0)
				{
					count++;
				}
			}
			if(count==0)
			{
				System.out.println(i+" ");
			}
			count=0;
		}
		
		
		
	}

}
