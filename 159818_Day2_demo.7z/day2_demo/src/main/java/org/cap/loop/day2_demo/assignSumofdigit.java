package org.cap.loop.day2_demo;

public class assignSumofdigit {

	public static void main(String[] args) {
		
		//2.	Write a program to find sum of digit
		
		
		int number=123;
		
		int sum=0,remainder;
		
		while(number>0)
		{
			remainder=number %10;
			sum = sum + remainder;
			number=number/10;
		}
		
		System.out.println("sum is "+sum);
		
	}

}
