package org.cap.loop.day2_demo;

public class day2Assign1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
