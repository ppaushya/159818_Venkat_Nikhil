package org.cap.loop.day2_demo;

public class forDemo {

	public static void main(String[] args) {
		
		
		int i;
		
		for(i=1;i<=10;i++)
		{
			System.out.println(i);
		}
       
		for(i=1;i<=10;i++);
		System.out.println(i);
		
	}

}
