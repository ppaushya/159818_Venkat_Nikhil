package org.cap.loop.day2_demo;

public class nested_loopdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		int count=0;
		
		for(int i=1;i<=10;i++)
		{
			for(int j=1;j<=10;j++)
			{
				System.out.print(i*j + " ");
				count++;
			}
			System.out.println();
		}
		System.out.println(count);
	
		
		
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*\t");
			}
			System.out.println();
		}
		
		
		
	
		//problem1
		
		int i,j,k;
		
		for(i=0;i<4;i++)
		{
			for(j=0;j<i;j++)
			{
				System.out.print(" ");
			}
			for(k=i;k<4;k++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		
		//problem 2
		
		int i,j,count=0;
		
		for(i=0;i<4;i++)
		{
          for(j=0;j<=i;j++)
          {
        	  count++;
        	  System.out.print(count+" ");
          }
          System.out.println();
		}
		
		*/
		
		int i,j,k,count=0;
		
		int n;
		
		for(i=0;i<=4;i++)
		{
			for(j=0;j<=4-i-1;j++)
			{
				System.out.print(" ");
			}
			n=1;
			for(k=0;k<=i;k++)
			{
				System.out.print(n + " ");
				n=(n)*(i-k)/(k+1);
			}
			System.out.println();
		}
		
	}

}

