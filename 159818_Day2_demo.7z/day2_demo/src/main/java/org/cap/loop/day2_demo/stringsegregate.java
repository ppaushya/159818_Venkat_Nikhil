package org.cap.loop.day2_demo;

public class stringsegregate {

	public static void main(String[] args) {
		
		
		String name="hello";
		
		int i=name.length();
		int j=0,k;
		
		while(j<i)
		{
		  for(k=0;k<=j;k++)
		  {
			  System.out.print(name.charAt(k));
		  }
		  System.out.println();
		  j++;
		}
		

	}

}
