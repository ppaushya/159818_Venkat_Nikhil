package org.capg.boot;

public class TestClass {

	public static void main(String[] args) {
		String str="8901289012";
		System.out.println(str.matches("(7|8|9)\\d{9}"));
	}

}
