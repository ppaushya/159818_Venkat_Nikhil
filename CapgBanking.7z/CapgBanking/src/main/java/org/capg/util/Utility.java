package org.capg.util;

public class Utility {
	
	public static int generateNumber() {
		return (int)(Math.random()*1000)/100;
	}
	
	public static boolean isValidName(String name) {
		return name.matches("[a-zA-Z]{3,}");
	}

	
	public static boolean isValidEmail(String email) {
		return email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}
	
	
	public static boolean isValidMobile(String mobile) {
		return mobile.matches("\\d{10}");
	}

	public static boolean isValidDob(String dob) {
		
		return dob.matches("[0,1,2,3]\\d{1}-[0,1]\\d{1}-(18|19|20)\\d{2}");
	}
	
	public static boolean isValidPincode(String pincode) {
		return pincode.matches("\\d{6}");
	}
	
}
