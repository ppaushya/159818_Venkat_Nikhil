package org.cap.account.test;

public interface LoginCategory {

}
