package org.cap.account.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.cap.demo.Calculate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)

public class ParameterizedTest {

	private int[] input1;
	private int output;
	
	Calculate cal=new Calculate();
	
	
	
	
	public ParameterizedTest(int[] input1, int output) {
		super();
		this.input1 = input1;
		this.output = output;
	}






	@Parameters
	
	public static List<Object[]> getParams()
	{
		return Arrays.asList(new Object[][]
				{
			{new int[]{1,2,3},6},
			{new int[]{1},1},
			{new int[]{1,2},3}
			});
	}
	
	@Test
	
	public void test()
	{
		assertEquals(output,cal.addArray(input1));
	}
	
}
