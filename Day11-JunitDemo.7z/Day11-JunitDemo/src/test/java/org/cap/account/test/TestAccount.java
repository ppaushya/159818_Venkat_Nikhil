package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.dao.IAccountDao;
import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


public class TestAccount {
	@Mock
	private IAccountDao accountDao;
	
	private IAccountService accountService;
	
	@BeforeClass
	public static void beforeClass() {
		//System.out.println("Before Class Method...");
	}
	
	@AfterClass
	public static void afterClass() {
		//System.out.println("After Class Method...");
	}
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
	}
	
	@After
	public void tearDown() {
		//System.out.println("Object release here....");
	}
	
	@Category(LoginCategory.class)
	@Test
	public void test_add_account() throws InvalidAmountException {
		
		Customer customer=new Customer();
		customer.setCustomerId(1001);
		customer.setCustomerName("Tom");
		Address address=new Address();
		address.setAddressline("23,North Avvenue");
		customer.setAddress(address);
		
		//dummy Declaration
		Mockito.when(accountDao.addAccount(customer)).thenReturn(true);
		
		
		//Actual Logic Triggered
		Account account=accountService.createAccount(customer, 3000);
		
		
		//verification
		Mockito.verify(accountDao).addAccount(customer);
		assertNotNull(account);
		assertEquals(account.getBalance(), account.getBalance(),0.0);
		
	}
	
	
	@Category(LoginCategory.class)
	@Test
	
	public void test_withdraw_method()
	{
		Account acc=new Account();
		
		acc.setAccountNo(101);
		acc.setAccountType("savings");
		acc.setBalance(12000);
		
		Mockito.when(accountDao.findAccount(101)).thenReturn(acc);
		
		Account acc2=accountService.withdraw(acc, 1000);
		
		Mockito.verify(accountDao).findAccount(101);
		
		
		assertEquals(11000, acc.getBalance(),0.0);
		
		
	}
	
	@Test
	
	public void test_deposit_method()
	{
		Account acc=new Account();
		
		acc.setAccountNo(101);
		acc.setAccountType("savings");
		acc.setBalance(12000);
		
		Mockito.when(accountDao.findAccount(101)).thenReturn(acc);
		
		Account acc2=accountService.deposit(acc, 1000);
		
		Mockito.verify(accountDao).findAccount(101);
		
		assertEquals(13000, acc.getBalance(),0.0);
		
		
	}
	
	
	@Test(expected=IllegalArgumentException.class)
	public void when_createAccount_with_null_customer()
				throws InvalidAmountException {
		
		//System.out.println("when_createAccount_with_null_customer");
		Customer customer=null;
		
		accountService.createAccount(customer, 3000);
	}
	
	
	@Test(expected=InvalidAmountException.class)
	public void when_createAccount_with_invalid_amount() 
			throws InvalidAmountException {
	//	System.out.println("when_createAccount_with_invalid_amount");
		Customer customer=new Customer();
		customer.setCustomerId(1001);
		customer.setCustomerName("Tom");
		Address address=new Address();
		address.setAddressline("23,North Avvenue");
		customer.setAddress(address);
		
		
		accountService.createAccount(customer, 300);
	}

}











