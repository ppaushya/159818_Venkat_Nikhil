package org.cap.account.test;

import static org.junit.Assert.assertTrue;

import org.junit.Assume;
import org.junit.experimental.theories.*;
import org.junit.runner.RunWith;

@RunWith(Theories.class)

public class TheoryTest {

	@DataPoints
	
	public static int[] getData()
	{
		return new int[] {1,2,3,4,5,6,0,-1,-2};
	}
	
	@Theory
	
	public void proveStatement(int a,int b)
	{
		System.out.println(a+" "+b);
		Assume.assumeTrue(a>0 && b>0);
		assertTrue(a+b>0);
	}
	
}
