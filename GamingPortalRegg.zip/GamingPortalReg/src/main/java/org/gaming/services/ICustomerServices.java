package org.gaming.services;

import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;

public interface ICustomerServices {

	public boolean doCustomerRegistration(Registration registration) throws InvalidCustomerException;
	
	
}
