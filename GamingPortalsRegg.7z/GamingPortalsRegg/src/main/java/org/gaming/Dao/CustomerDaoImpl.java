package org.gaming.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import org.gaming.model.Registration;
import org.gaming.services.CustomerServicesImpl;

import com.mysql.jdbc.PreparedStatement;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public boolean doCustomerRegistration(Registration registration) {
		// TODO Auto-generated method stub
		CustomerServicesImpl obj=new CustomerServicesImpl();
		String sql = "insert into registration(customername,mobilenumber,registrationfee,age,actualregfeepaid) values(?,?,?,?,?)";
		String sql1="select * from registration";
		try(Connection conn = getDbConnection())
		{
		     java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		     pst.setString(1, registration.getCustomerName());
		     pst.setString(2, registration.getMobileNumber());
		     pst.setDouble(3,registration.getRegistrationFee());
		     pst.setInt(4, registration.getAge());
		     pst.setDouble(5, registration.getActualRegFeePaid());
		    
		     int count=pst.executeUpdate();		    
		     
		     int count1;
		     

		     if(count>=1)
		     {
		    	
		    	 
		    	 System.out.println("insertion done!");
		    	
		    	 java.sql.PreparedStatement pst1=conn.prepareStatement(sql1);
			     
			     ResultSet res=pst1.executeQuery();
			     
			     while(res.next())
			     {
			    	 if(res.getString(2).compareTo(registration.getCustomerName())==0)
			    	 {
			    		 System.out.println("Reg Id : " +res.getInt(1));
					     System.out.println("congrats " +res.getString(2)+" u have succesfully created the account");
			    	   
			    	 }
			     }
		    	 
		     }

		     else
		     {
		    	 return false;
		     }
		    
		     
		    
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			obj.logger.error("connection error",e);
			//e.printStackTrace();
		}
		
	return true;	
		
	}
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}

}
