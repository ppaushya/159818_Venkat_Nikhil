package org.cap.demo;

import org.apache.log4j.Logger;

public class HelloExample {

	
	final static Logger logger = Logger.getLogger(HelloExample.class);
	
	public static void main(String[] args)
	{
		HelloExample obj=new HelloExample();
		obj.runMe("message");
	}
	
	private void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("this is debug :" + parameter);
		}
		
		if(logger.isInfoEnabled())
		{
			logger.debug("this is info :" + parameter);
		}
		
		
		int num1=45,num2=0;
		
		int ans;
		
		try
		{
			ans=num1/num2;
		}
		catch(ArithmeticException e)
		{
			logger.error("sorry something is wrong",e);
		}
		
		
		logger.warn("this is warn" + parameter);
		logger.error("this is error :" + parameter);
		logger.fatal("this is fatal "+parameter);
	}
	
	
	
}
