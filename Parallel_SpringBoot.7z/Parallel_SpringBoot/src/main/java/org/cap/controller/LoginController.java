package org.cap.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/p1")
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	@PostMapping("/validlogin")
	public ResponseEntity<Customer> getCustomer(@RequestBody Customer customer)
	{
		Customer customer1=loginService.getCustomer(customer.getEmailId(),customer.getCustomerPwd());
		
		//System.out.println(customer1);

		if(customer1==null)
		{
			return null;
		}
		
		return new ResponseEntity<Customer>(customer1,HttpStatus.OK);
		 
	
	}
		

	@PostMapping(value="/createcustomers")
	public ResponseEntity<List<Customer>> createCustomer(@RequestBody Customer customer){
		
	
	/*	Address address1 = new Address();
		address1.setAddressLine1("north avenue");
		address1.setAddressLine2("chennai");
		address1.setCity("hyderabad");
		address1.setState("andhra");
		address1.setPincode("622034");
		
		
		Customer customer=new Customer();
		
		customer.setFirstName("nikhil");
		customer.setCustomerPwd("123");
		customer.setEmailId("nik@gmail.com");
		customer.setLastName("venkat");
		customer.setMobile("7989499127");
		//customer.setAddress(address1);
		address1.setCustomer(customer);
		*/        
        List<Customer> customers=loginService.createPilot(customer);
        
        
       System.out.println("nikhil's here");
        
  
		
return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);		
		
	}
		

}
