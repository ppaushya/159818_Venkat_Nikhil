package org.cap.dao;

import javax.transaction.Transactional;

import org.cap.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
@Transactional
public interface ILoginDao extends JpaRepository<Customer,Integer>{
	
	@Query("from Customer c where c.emailId=:emailId and c.customerPwd=:customerPwd")
	public Customer getCustomer(String emailId, String customerPwd);

}
