package org.cap.service;

import java.util.List;

import org.cap.model.Address;
import org.cap.model.Customer;

public interface ILoginService {
	

   public Customer getCustomer(String emailId, String customerPwd);

	public List<Customer> createPilot(Customer customer);

}
