package org.cap.service;

import java.util.List;

import org.cap.dao.ILoginDao;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("loginService")

public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	private ILoginDao loginDao;

	@Override
	public Customer getCustomer(String emailId, String customerPwd) {
		// TODO Auto-generated method stub
		return loginDao.getCustomer(emailId,customerPwd);
	}

	@Override
	public List<Customer> createPilot(Customer customer) {
		// TODO Auto-generated method stub

		 loginDao.save(customer);
		
		 return loginDao.findAll();
	} 


}
