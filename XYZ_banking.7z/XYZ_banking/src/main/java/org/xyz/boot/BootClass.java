package org.xyz.boot;

import org.xyz.services.CustomerServices;
import org.xyz.view.UserInteraction;
import org.xyz.services.CostumerServicesImplementation;

import java.util.List;

import org.xyz.model.Customer;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		UserInteraction userinteraction = new UserInteraction();
		
		System.out.println(userinteraction.getCustomerDetails());
		
		CustomerServices customeservice = new  CostumerServicesImplementation();
		
		List<Customer> costumers =customservice.getallcustomers();
		
		userinterface.printcustomers(customers);	
		}

}
