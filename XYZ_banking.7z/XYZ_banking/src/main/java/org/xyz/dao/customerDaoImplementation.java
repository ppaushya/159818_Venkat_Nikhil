package org.xyz.dao;

import java.util.ArrayList;
import java.util.List;

import org.xyz.model.Address;
import org.xyz.model.Customer;

public class customerDaoImplementation implements iCustomerDao {

	private List<Customer> customer;
	
	private static List<Customer> customers = dummydatabase();
	
	private static List<Customer> dummydatabase()
	{
		List<Customer> customers = new ArrayList<>();
		Address address = new Address(); //enter details
		customers.add(new Customer()); //enter details
		
		return customers;
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customers;
	}

	@Override
	public void createCustomers() {
		// TODO Auto-generated method stub
		
	}

	
	
}
