package org.xyz.services;

import java.time.LocalDate;

import org.xyz.dao.customerDaoImplementation;
import org.xyz.dao.iCustomerDao;
import org.xyz.model.Customer;

public class CostumerServicesImplementation implements CustomerServices {

	private iCustomerDao customerDao=new customerDaoImplementation();
	
	@Override
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		if(isValidCustomer(customer))
		{
			customerDao.createCustomers();
		}
	}
	
	private boolean isValidCustomer(Customer customer)
	{
		boolean flag=false;
		
		if(customer.getDateOfBirth().isBefore(LocalDate.now()))
		{
		if(customer.getMobileNo().matches("[7,8,9]\\d{9}")); 
		
	}
return flag;
	
	
}
}