package org.xyz.services;

import org.xyz.model.Customer;

public interface CustomerServices {

	public void createCustomer(Customer customer);
	
}
