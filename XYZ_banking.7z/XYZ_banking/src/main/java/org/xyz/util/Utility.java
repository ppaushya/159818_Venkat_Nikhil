package org.xyz.util;

public class Utility {

	
	public static int generateNumber()
	{
		return (int)(Math.random()*(1000))/(10);
	}
	
	
}
