package org.xyz.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import org.xyz.model.Address;
import org.xyz.model.Customer;
import org.xyz.util.Utility;

public class UserInteraction {

	
	Scanner scanner = new Scanner(System.in);
	
	
	public Customer getCustomerDetails()
	{
		 
		 Customer customers=new Customer();
		
		 customers.setCustomerId(Utility.generateNumber());
		 
	     customers.setFirstName(promptFirstName());
	     
	     customers.setLastName(promptLastName());
	    
	      customers.setMobileNo(promptMobileNumber());
	     
	      customers.setEmailId(promptEmailId());
	      
	      customers.setDateOfBirth(promptDateofBirth());
	      
	      customers.setAddress(promptAddress());
	      
	    return customers;
		 
	}
	
	public String promptFirstName()
	{
		String fname;
		
		boolean flag=false;
		
		do
		{
		System.out.println("enter the first name of the customer");
		
		fname=scanner.next();
		
		flag=fname.matches("[a-zA-Z]{3,}");
		
		if(!flag)
		{
			System.out.println("name is invalid enter one more time");
		}
		}while(!flag);
		
		
		
		return fname;
	}

	
	public String promptLastName()
	{
		String lname;
		
		boolean flag=false;
		
		do
		{
		System.out.println("enter the last name of the customer");
		
		lname=scanner.next();
		
		flag=lname.matches("[a-zA-Z]{3,}");
		
		if(!flag)
		{
			System.out.println("name is invalid enter one more time");
		}
		}while(!flag);
		
		
		
		return lname;
	}

	

	public String promptMobileNumber()
	{
		String mobilenumber;
		
		boolean flag=false;
		
		do
		{
		System.out.println("enter the mobile no of the customer");
		
		mobilenumber=scanner.next();
		
		flag=mobilenumber.matches("[0-9]{10}");
		
		if(!flag)
		{
			System.out.println("number is invalid enter one more time");
		}
		}while(!flag);
		
		
		
		return mobilenumber;
	}
	
	
	public String promptEmailId()
	{
		String emailid;
		
		boolean flag=false;
		
		do
		{
		System.out.println("enter the email id of the customer");
		
		emailid=scanner.next();
		
		flag=emailid.matches("[a-zA-Z]+[@]{1}(gmail){1}[.]{1}(com){1}");
		
		if(!flag)
		{
			System.out.println("email is invalid enter one more time");
		}
		}while(!flag);
		
		
		
		return emailid;
	}
    
	
	public LocalDate promptDateofBirth()
	{
		
		String dob;
		
		System.out.println("enter the dob");
		
		dob=scanner.next();
			
		String date1[]=dob.split("-");
	
		return LocalDate.of(Integer.parseInt(date1[2]), Integer.parseInt(date1[1]), Integer.parseInt(date1[0]));
	}
	
	
	public Address promptAddress()
	{
		Address obj=new Address();
		
		System.out.println("enter the lane1 address");
		
		obj.setAddressLine1(scanner.next());
		

		System.out.println("enter the lane2 address");
		
		obj.setAddressLine2(scanner.next());
		
		

		System.out.println("enter the city address");
		
		obj.setCity(scanner.next());;
		
	    

		System.out.println("enter the state address");
		
		obj.setState(scanner.next());	
		

		boolean flag=false;
		
		System.out.println("enter the pincode address");
		
		obj.setPinCode(scanner.nextLong());
		
		return obj;
		
	}
	
	public void printcustomers(List<Customer> customers)
	{
		for(Customer customer : customers)
		{
			System.out.println(customer.getDateOfBirth());
		}
	}
	
}



