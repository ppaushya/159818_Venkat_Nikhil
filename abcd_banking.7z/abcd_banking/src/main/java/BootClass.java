import java.util.List;
import java.util.Scanner;

import org.abcd.services.CustomerServices;
import org.abcd.services.CustomerServicesImpl;
import org.abcd.view.UserInteraction;
import org.xyz.model.Customer;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		UserInteraction userinteraction = new UserInteraction();
		
		CustomerServices customerservices = new CustomerServicesImpl();
		
		int ch,temp;
		
		boolean flag=true;
		
		String name;
		
		int l=0;
		
		while(flag)
		{
			System.out.println("1.create a customer");
			System.out.println("2.list the customers");
			System.out.println("3.create account for a customer");
			System.out.println("4.do transaction for a customer");
			ch=scanner.nextInt();
			
			if(ch==1)
			{
				customerservices.createCustomer(userinteraction.getCustomerDetails());
				
			}
			else if(ch==2)
			{
				List<Customer> customers = customerservices.getAllCustomers();
				userinteraction.printallcustomers(customers);
			}
			
			else if(ch==3)
			{

				List<Customer> customers = customerservices.getAllCustomers();
				Customer customer=userinteraction.findallcustomers(customers);
				
				if(customer==null)
				{
					System.out.println("invalid customer name");
				}
				else
				{
				  userinteraction.createaccounts(customer);
				  System.out.println(customer.getAccounts());
				}
				
				
			}
			
			else if(ch==4)
			{
				List<Customer> customers = customerservices.getAllCustomers();
				Customer customer=userinteraction.findallcustomers(customers);
				Customer customer1=userinteraction.findallcustomers(customers);
				if(customer==null || customer1==null)
				{
					System.out.println("invalid customer name");
				}
				else
				{
				  userinteraction.dotransactions(customer,customer1);
				}
				
			}
			
			System.out.println("enter 1 to continue and 2 to exit");
			temp=scanner.nextInt();
			
			if(temp==2)
			{
				flag=false;
			}
		}
		
		
	}

}
