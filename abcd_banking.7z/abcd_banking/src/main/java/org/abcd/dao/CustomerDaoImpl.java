package org.abcd.dao;

import java.util.ArrayList;
import java.util.List;

import org.xyz.model.Address;
import org.xyz.model.Customer;

public class CustomerDaoImpl implements ICustomerDao{

	private static List<Customer> customers = dummydb();
	
	private static List<Customer> dummydb()
	{
		List<Customer> customers = new ArrayList<>();
		
		Address address= new Address("ab","bc","cd","de",522);
		
		customers.add(new Customer(10,"nikhil","venkat","nik@gmail.com","7989499127",address));
		
		Address address1= new Address("ab","bc","cd","de",522);
		
		customers.add(new Customer(11,"akhil","venkat","ni@gmail.com","7989499127",address1));
		
		return customers;
	}
	
	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		customers.add(customer);
	}

	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customers;
	}

	
	
}
