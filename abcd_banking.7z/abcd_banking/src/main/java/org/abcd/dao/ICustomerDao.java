package org.abcd.dao;

import java.util.List;

import org.xyz.model.Customer;

public interface ICustomerDao {

	public void createCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
	
	
}
