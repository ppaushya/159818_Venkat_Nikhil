package org.abcd.util;

public class Utility {

	public static int generaterandom()
	{
		return (int)(Math.random()*1000)/10;
	}
	
	
	
}
