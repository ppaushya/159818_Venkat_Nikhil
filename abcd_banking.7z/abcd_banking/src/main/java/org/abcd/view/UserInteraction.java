package org.abcd.view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.abcd.util.Utility;
import org.xyz.model.Account;
import org.xyz.model.Address;
import org.xyz.model.Customer;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	
	ArrayList<Set<Account>> lst = new ArrayList<>();
	
	public Customer getCustomerDetails()
	{
		Customer customer = new Customer();
		
		customer.setCustomerId(Utility.generaterandom());
		
		customer.setFirstName(promptfirstname());
		
		customer.setLastName(promptlastname());
		
	customer.setEmailId(promptemailid());
	
	customer.setMobileNo(promptmobileno());
	
	customer.setAddress(promptaddress());
		
		return customer;
	}

	
	public String promptfirstname()
	{
		String fname;
		
		
		boolean flag=false;
		
		do
		{
			System.out.println("enter the first name of the customer");
			
			fname=scanner.next();
			
			flag=fname.matches("[a-zA-Z]+");
			
			if(!flag)
			{
				System.out.println("enter one mpre time as the name is invalid");
			}
		}while(!flag);
		return fname;
	}
	
	
	public String promptlastname()
	{
		String lname;
		
		
		boolean flag=false;
		
		do
		{
			System.out.println("enter the last name of the customer");
			
			lname=scanner.next();
			
			flag=lname.matches("[a-zA-Z]+");
			
			if(!flag)
			{
				System.out.println("enter one mpre time as the name is invalid");
			}
		}while(!flag);
		return lname;
	}
	
	public String promptemailid()
	{
		String email;
		
		
		boolean flag=false;
		
		do
		{
			System.out.println("enter the email of the customer");
			
			email=scanner.next();
			
			flag=email.matches("[a-zA-Z]+[@]{1}(gmail){1}[.]{1}(com){1}");
			
			if(!flag)
			{
				System.out.println("enter one mpre time as the name is invalid");
			}
		}while(!flag);
		return email;
	}
	
	public String promptmobileno()
	{
String mobile;
		
		
		boolean flag=false;
		
		do
		{
			System.out.println("enter the mobile no of the customer");
			
			mobile=scanner.next();
			
			flag=mobile.matches("[0-9]{10}");
			
			if(!flag)
			{
				System.out.println("enter one mpre time as the mobile no is invalid");
			}
		}while(!flag);
		return mobile;
	}
	
	public Address promptaddress()
	{
		Address address = new Address();
		
		String line1,line2,city,state;
		
		long pincode;
		
		System.out.println("enter the lane 1 address");
		
		line1=scanner.next();
		
System.out.println("enter the lane 2 address");
		
		line2=scanner.next();
System.out.println("enter the city address");
		
		city=scanner.next();
System.out.println("enter the state address");
		
		state=scanner.next();
		
System.out.println("enter the pincode address");
		
		pincode=scanner.nextLong();
		
		address.setAddressLine1(line1);
		
		address.setAddressline2(line2);
		
		address.setCity(city);
		
address.setState(state);

address.setPincode(pincode);
		
		return address;
	}
	
	
	public void printallcustomers(List<Customer> customers)
	{
		System.out.println("customer database");
		for(Customer cs : customers)
		{
			System.out.println(cs.getCustomerId()+"  " +cs.getFirstName()+cs.getLastName() +" " + cs.getEmailId()+" " + cs.getMobileNo() + cs.getAddress());
		}
	}
	
	
	public Customer findallcustomers(List<Customer> customers)
	{
		
		System.out.println("enter the name of the customer u want to create acocunt");
		
		String name;
		
		name=scanner.next();
		
		for(Customer cs : customers)
		{
			//System.out.println(cs.getCustomerId()+"  " +cs.getFirstName()+cs.getLastName() +" " + cs.getEmailId()+" " + cs.getMobileNo() + cs.getAddress());
	 
		if(name.compareTo(cs.getFirstName())==0)
		{
			return cs;
		}
		
		}
		
		return null;
	}
	
	
	public void createaccounts(Customer customer)
	{
		Set<Account> accountss=new HashSet<>();

		boolean flag=true;
		
		System.out.println("enter the name of the account you want to create");
		
		String type=scanner.next();
	
		Account account=new Account();
		
       	if(customer.getAccounts().size()==0)
       	{
       		account.setAccountNo(Utility.generaterandom());
    		
    		account.setAccType(type);
    		
    		account.setAccountopeningbal(1000);
    		
    		account.setDescription("this account is "+type);
    		
    		account.setAccOpeningDate(LocalDate.of(1996,10,12));
    		
    		accountss.add(account);
    		
    		lst.add(customer.getCustomerId(),accountss );
    		
    		customer.setAccounts(lst.get(customer.getCustomerId()));
       	}
		
	
	/*	
		Account account=new Account();
		
       for(Account ac : accountss )
       {
    	   if(ac.getAccType().compareTo(type)==0)
    	   {
    		   System.out.println("account already exists");
    		   flag=false;
    	   }
       }
		
       if(flag)
       {
		account.setAccountNo(Utility.generaterandom());
		
		account.setAccType(type);
		
		account.setAccountopeningbal(1000);
		
		account.setDescription("this account is "+type);
		
		account.setAccOpeningDate(LocalDate.of(1996,10,12));
		
		accountss.add(account);
		
		customer.setAccounts(accountss);
       }
*/
	}
	
	
	public void dotransactions(Customer cust1,Customer cust2)
	{
		 String type1,type2;
		 
		 System.out.println("1.deposit");
		 System.out.println("2.withdrawal");
		 
		 int ch=scanner.nextInt();
		 
		 double maxbal,sending;
		 
		 System.out.println("enter the type of the account customer wants to debit from his account");
		 type1=scanner.next();
		 
		 Account account=new Account(); 
		 
		
		 
	}
	
	
}


