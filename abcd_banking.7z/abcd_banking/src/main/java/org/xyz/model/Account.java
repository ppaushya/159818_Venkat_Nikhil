package org.xyz.model;

import java.time.LocalDate;

public class Account {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accOpeningDate == null) ? 0 : accOpeningDate.hashCode());
		result = prime * result + ((accType == null) ? 0 : accType.hashCode());
		result = prime * result + (int) (accountNo ^ (accountNo >>> 32));
		long temp;
		temp = Double.doubleToLongBits(accountopeningbal);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accOpeningDate == null) {
			if (other.accOpeningDate != null)
				return false;
		} else if (!accOpeningDate.equals(other.accOpeningDate))
			return false;
		if (accType == null) {
			if (other.accType != null)
				return false;
		} else if (!accType.equals(other.accType))
			return false;
		if (accountNo != other.accountNo)
			return false;
		if (Double.doubleToLongBits(accountopeningbal) != Double.doubleToLongBits(other.accountopeningbal))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		return true;
	}

	private long accountNo;
	
	private String accType;
	
	private LocalDate accOpeningDate;
	
	private double accountopeningbal;
	
	private String description;

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public LocalDate getAccOpeningDate() {
		return accOpeningDate;
	}

	public void setAccOpeningDate(LocalDate accOpeningDate) {
		this.accOpeningDate = accOpeningDate;
	}

	public double getAccountopeningbal() {
		return accountopeningbal;
	}

	public void setAccountopeningbal(double accountopeningbal) {
		this.accountopeningbal = accountopeningbal;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accType=" + accType + ", accOpeningDate=" + accOpeningDate
				+ ", accountopeningbal=" + accountopeningbal + ", description=" + description + "]";
	}

	public Account(long accountNo, String accType, LocalDate accOpeningDate, double accountopeningbal,
			String description) {
		super();
		this.accountNo = accountNo;
		this.accType = accType;
		this.accOpeningDate = accOpeningDate;
		this.accountopeningbal = accountopeningbal;
		this.description = description;
	}

	public Account() {
		super();
	}
	
	
	
}
