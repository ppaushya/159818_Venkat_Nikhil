import { Component,OnInit} from '@angular/core'

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
 
})
    export class HomePageComponent implements OnInit {
    
      public imagesUrl;

      ngOnInit() {
    
       this.imagesUrl = [
      'https://rukminim1.flixcart.com/flap/960/960/image/adc5eb3b6e6e4360.jpg?q=50',
     'https://pbs.twimg.com/media/DgntWXeWsAEcQ4f.jpg',
     'http://ios.gopaisa.com/routes/upload/snapdeal-offers.jpg'
    
     ]; 
     
    
       }
    
    } 
   


