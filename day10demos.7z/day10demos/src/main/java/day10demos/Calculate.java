package day10demos;

public class Calculate<T,R> {

	T num1;
	R num2;
	public T getNum1() {
		return num1;
	}
	public void setNum1(T num1) {
		this.num1 = num1;
	}
	public R getNum2() {
		return num2;
	}
	public void setNum2(R num2) {
		this.num2 = num2;
	}
	
	
	
}
