package org.cap.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class TestJDBC 
{
   public static void main(String[] args)
   {
	   Connection connection=null;
	//1.load driver class   
	   try
	   {
	   Class.forName("com.mysql.jdbc.Driver");
	   }
	   catch(ClassNotFoundException e)
	   {
		   e.printStackTrace();
	   }
	   
	   
	  //2.create connection
	   try
	   {
	   connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Customer", "root", "India123");
	   
	//   String sql="create table address1(customid int  ,addressline1 varchar(25) not null,"
	   //		+ "addressline2 varchar(25),city varchar(25),state varchar(25),Foreign key(customid) references customer(custid))";
	   
	   String sql="create table accounts(customerid int  ,accountno numeric(8,2) not null,"
		   		+ "accounttype varchar(25),openingbal numeric(8,2),description varchar(25),Foreign key(customerid) references customer(custid))";
		   
	   
	   //3.statement
	   
	   Statement statement=connection.createStatement();
	   
	   
	   boolean flag=statement.execute(sql);
	   
	   if(!flag)
	   {
		   System.out.println("table created successfully");
	   }
	   else
	   {
		   System.out.println("table creation error");
	   }
	   
	   }
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   finally {
		   try
		   {
		connection.close();
		   }
		   catch(SQLException e)
		   {
			   e.printStackTrace();
		   }
	}
	   
	   
   }
}
