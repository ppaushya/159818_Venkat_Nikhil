function validate()
{

var username=f1.username.value;

var password=f1.password.value;


if(username.equals("tom") && password.equals("tom123"))
{
alert("tom");
}
else
{
alert("wrong password");
}
}