package day1spring5core;

import java.util.List;

public class Collectionsdemo {

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	private List<String> names;
	
	private List<Address> addresses;

	@Override
	public String toString() {
		return "Collectionsdemo [names=" + names + ", addresses=" + addresses + "]";
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	
}
