package org.cap.boot;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import day1spring5core.Employee;

public class Testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

    AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		
		Employee emp=(Employee)context.getBean("emp");
		
		Employee emp1=(Employee)context.getBean("emp");
		
		emp.setEmployeeName("nikhil");
		
		System.out.println(emp);
		
		System.out.println(emp1);
		
		context.registerShutdownHook();
	
		//context.close();
		
	}

}
