package org.cap.boot;

import java.util.Collection;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import day1spring5core.Collectionsdemo;
import day1spring5core.Employee;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("collectionBean.xml");
		
		Collectionsdemo names=(Collectionsdemo)context.getBean("mydemo");
		
		Employee emp=(Employee)context.getBean("emp");
		
		System.out.println(names);
		
		System.out.println(emp);
		
		
	}

}
