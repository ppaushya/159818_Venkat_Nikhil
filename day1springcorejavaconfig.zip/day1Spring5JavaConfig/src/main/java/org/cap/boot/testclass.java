package org.cap.boot;

import org.cap.config.JavaConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import day1spring5core.Collectionsdemo;
import day1spring5core.Employee;

public class testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
		
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);		
		
		Employee emp=context.getBean(Employee.class);
	
		Employee emp1=context.getBean(Employee.class);
		
		emp.setEmployeeName("venkat");
		
		System.out.println(emp);
		
		System.out.println(emp1);
		
		//context.close();
		
		context.registerShutdownHook();
	}

	
	
}
