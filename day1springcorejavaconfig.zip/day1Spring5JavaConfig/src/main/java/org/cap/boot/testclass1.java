package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.config.Myconfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import day1spring5core.Collectionsdemo;
import day1spring5core.Employee;

public class testclass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(Myconfig.class);	
		
		String wish=context.getBean(String.class);
		
		Employee emp=context.getBean(Employee.class);

		
		System.out.println(wish);
		System.out.println(emp);
		
	}

}
