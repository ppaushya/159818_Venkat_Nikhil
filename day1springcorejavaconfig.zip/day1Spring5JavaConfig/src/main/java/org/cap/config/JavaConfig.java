package org.cap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import day1spring5core.Address;
import day1spring5core.Employee;

@Configuration

public class JavaConfig {

	@Bean
	//@Scope("prototype")
	public Employee getEmployeeBean()
	{
		Employee emps=new Employee();
		
		emps.setEmployeeName("tom");
		emps.setSalary(10000);
		
		//return new Employee(100,"nikhil",1000);
		
		return emps;
	}
	
	@Bean(name="address1")
	
	public Address Getaddressbean()
	{
		return new Address("north avenue", "chennai");
	}
	
@Bean(name="address2")
	
	public Address Getaddressbean1()
	{
		return new Address("south avenue", "pune");
	}
	
}
