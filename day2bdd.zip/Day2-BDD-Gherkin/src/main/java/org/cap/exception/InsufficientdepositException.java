package org.cap.exception;

public class InsufficientdepositException extends Exception {

	public InsufficientdepositException(String msg) {
		super(msg);
	}
	
	
}
