package org.cap.service;

import org.cap.exception.InsufficientbalanceException;
import org.cap.exception.InsufficientdepositException;
import org.cap.model.Account;
import org.cap.model.Customer;

public interface IAccountService {

	public Account createAccount(Customer customer,double balance) throws InsufficientbalanceException;

	public Account verifyAccount(Account account, int i) throws InsufficientdepositException;
}
