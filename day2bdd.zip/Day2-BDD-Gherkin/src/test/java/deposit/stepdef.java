package deposit;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.cap.dao.IAccountDao;
import org.cap.exception.InsufficientbalanceException;
import org.cap.exception.InsufficientdepositException;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	@Rule
	public ExpectedException thrown=ExpectedException.none();
	private double balance;
	
	private IAccountService accountService;
	
	private Customer customer;
	
	private Account account;
	
	private static int amount;
	
	@Mock
	private IAccountDao accountDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	
	

@Given("^Account details$")
public void account_details() throws Throwable {

	Account account=new Account(1);
	
}

@When("^Valid  Details$")
public void valid_Details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	assertNotNull(account);
	
}

@Then("^deposit money$")
public void deposit_money() throws Throwable {
    
	amount=500;
	
}

@Given("^Account details and depositamount$")
public void account_details_and_depositamount() throws Throwable {
	   account=null;
}

@When("^Invalid Account Details$")
public void invalid_Account_Details() throws Throwable {
   assertNull(account);
}




@Then("^throw error message 'Invalid Account Details'$")
public void throw_error_message_Invalid_Account_Details() throws Throwable {
   
	thrown.expect(IllegalArgumentException.class);
	thrown.expectMessage("Sorry! Invalid account detailsr");
	
	accountService.verifyAccount(account, 200);
	
}

@Given("^Valid Account details$")
public void valid_Account_details() throws Throwable {

	Account account=new Account(1);


}

@Given("^depositamount$")
public void depositamount() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}

@When("^Invalid depsoitamount$")
public void invalid_depsoitamount() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	amount=-200;
}


@Rule
public ExpectedException thrown1=ExpectedException.none();
@Then("^throw error message 'Insufficient deposit Balance'$")
public void throw_error_message_Insufficient_deposit_Balance() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	thrown1.expect(InsufficientdepositException.class);
	thrown1.expectMessage("Insufficient deposit Balance");
	
	accountService.verifyAccount(account, amount);
	
}

	
	
}
