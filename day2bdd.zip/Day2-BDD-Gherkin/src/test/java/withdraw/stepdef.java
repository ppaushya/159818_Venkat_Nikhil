package withdraw;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.cap.dao.IAccountDao;
import org.cap.exception.InsufficientdepositException;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	

	@Rule
	public ExpectedException thrown=ExpectedException.none();
	private double balance;
	
	private IAccountService accountService;
	
	private Customer customer;
	
	private Account account;
	
	private static int amount;
	
	@Mock
	private IAccountDao accountDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	
	
	@Given("^Account details$")
	public void account_details() throws Throwable {
	    account=new Account(3);
	      
	}

	@When("^Valid  Details$")
	public void valid_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
         assertNotNull(account);   	      
	}

	@Then("^withdraw money$")
	public void withdraw_money() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      amount=100;
	}

	@Given("^Account details and withdrawamount$")
	public void account_details_and_withdrawamount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      account=null;
	}

	@When("^Invalid Account Details$")
	public void invalid_Account_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      assertNull(account);
	}

	
	
	@Then("^throw error message 'Invalid Account Details'$")
	public void throw_error_message_Invalid_Account_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Sorry! Invalid account");
		accountService.verifyAccount(account, 1000);
		
	}

	@Given("^Valid Account details$")
	public void valid_Account_details() throws Throwable {
	   account=new Account(4);
	      
	}

	@Given("^withdrawamount$")
	public void withdrawamount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^Invalid withdrawamount$")
	public void invalid_withdrawamount() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      amount=-200;

	}

@Rule
public ExpectedException thrown1=ExpectedException.none();
@Then("^throw error message 'Insufficient deposit Balance'$")
	public void throw_error_message_Insufficient_withdraw_Balance() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	      
	

	thrown1.expect(InsufficientdepositException.class);
	thrown1.expectMessage("Insufficient deposit Balance");
	
	accountService.verifyAccount(account, amount);
	
	
	}


	
	
}
