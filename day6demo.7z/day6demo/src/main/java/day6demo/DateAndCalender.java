package day6demo;

import java.util.Date;

public class DateAndCalender {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d=new Date();
		
		System.out.println(d);
		
		Date d2=new Date(1991,01,23);
		
		System.out.println(d2);
		
		System.out.println(d2.getTime());
		
		System.out.println(d.getTime());
		
		Date d3=new Date(1538369717234l);
		System.out.println(d3);
		
		Date d4=new Date();
		
		System.out.println(d4.after(d3));
		
		System.out.println(d4.before(d3));
		
		System.out.println(d4.getDate());
		
		System.out.println(d4.getDay());
		
		System.out.println(d4.getHours());

		System.out.println(d4.getMinutes());
		
		System.out.println(d4.getMonth());
		
		System.out.println(d4.getSeconds());
		
		System.out.println(d4.getTime());
		
		System.out.println(d4.getYear()+1900);
		
		d4.setDate(5);
		
		System.out.println(d4.getDate());
		
		
	}

}
