package day6demo;

public class NormalInnerClass {

	int num=100;
	String name="nikhil";
	
	class innercl
	{
		String address="nikhil";
		public void show()
		{
			System.out.println(address);
			System.out.println(name);
			
		}
	}
	
	public void print()
	{
		innercl obj=new innercl();
		System.out.println(obj.address);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
           
		
		
	}

}
