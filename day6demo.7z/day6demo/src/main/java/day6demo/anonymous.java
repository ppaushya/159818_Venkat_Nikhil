package day6demo;

public abstract class anonymous {

	abstract void print();

}
