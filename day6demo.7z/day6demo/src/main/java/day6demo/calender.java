package day6demo;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class calender {


	
	public static void main(String[] args) {
		
		Instant instant= Instant.now();
			
		System.out.println(instant);
		
		System.out.println(Instant.MAX);
		
		System.out.println(Instant.MIN);
		
		
		//instant is immutable
		
		
		//2.duration
		
		//3.local date
		
		LocalDate date=LocalDate.now();
		
		System.out.println(date);
		
		//4.local time
		
		LocalTime time=LocalTime.now();
		
		System.out.println(time);
		
		//5.period
		
		LocalDate date2= LocalDate.of(2002, 02, 10);
		
		System.out.println(date2);

		Period per=Period.between(date2, date);
		
		System.out.println(per.getMonths());
		
		System.out.println(per.getYears());

		
		
		//6.date adjuster
		
		LocalDate d=LocalDate.now();
		
		System.out.println(d.with(TemporalAdjusters.next(DayOfWeek.SUNDAY)));
		
      //zones
		
		java.util.Set<String> zones= ZoneId.getAvailableZoneIds();
		
		for(String zone : zones)
		{
			System.out.println(zone);
		}
				
		
		//zoned time date meet
		
	//	System.out.println(DateTimeFormatter.ISO_DATE_TIME.format(meeting));
		
		
		
		// TODO Auto-generated method stub
    /*
		Calendar c = new GregorianCalendar();
		
		//System.out.println(c);
       
		//c.add(c.ERA, 1);
		
	//	System.out.println(c.get(c.DAY_OF_MONTH));
		
		Calendar today = c.getInstance();
		
		//System.out.println(today);
		
		System.out.println(today.getTime());
		
		 today.add(c.YEAR, 3);
		
		 //System.out.println(today);
		
		// System.out.println(today.set(c.YEAR, 10));
		 
		 System.out.println(today.getMinimum(c.YEAR));
		 
		 System.out.println(today.getMaximum(c.YEAR));
	
		 System.out.println(today.getMaximum(c.MONTH));
		 
		 System.out.println(today.getMinimum(c.MONTH));
		*/ 
	}

}
