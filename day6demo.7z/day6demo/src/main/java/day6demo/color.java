package day6demo;

public enum color {

/*
	public enum type
	{
		
	}
	
	*/
	
	
}
