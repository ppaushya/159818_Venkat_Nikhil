package day6demo;

import java.text.DateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;



public class demo1time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DateFormat format=DateFormat.getDateInstance();
		
		//System.out.println(format.format(new Date()));
		
		Instant instant=Instant.now();
		
		//instant to date
		
		Date d=Date.from(instant);
		
		System.out.println(d+"\n"+instant);
		
		//date to instant
		
		Instant temp=d.toInstant();
		
		System.out.println(temp);
		
		//instant to timestamp
		
		
		java.sql.Timestamp time=java.sql.Timestamp.from(instant);
		
		System.out.println(time);
		
		//timestamp to instant
		
		Instant i=time.toInstant();
		
		System.out.println(i);
		
		
		//localdate and date
		
       
		
	}

}
