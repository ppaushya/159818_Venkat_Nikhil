package day6demo;

public class demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  /*
		StringBuffer sb= new StringBuffer("nikhil");
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		sb.append("marabathula venkat");
		
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		sb.replace(0, 6, "vebkat");
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		*/
	

		StringBuilder sb= new StringBuilder(50);
		
		sb.append("nikhil");
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		sb.append("marabathula venkat");
		
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		sb.replace(0, 6, "venkat");
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
		sb.ensureCapacity(100);
		
		System.out.println(sb+"\n"+sb.length()+"\n"+sb.capacity());
		
	}

}
