package day6demo;

public class exercise {

	public static void main(String[] args) {
		
		Integer num=100;
		
		Integer mynum=new Integer(100);
		
		Integer value=100;
	
		Integer myvalue = new Integer(100);
		
	  System.out.println(num.equals(mynum));	
	  
	  System.out.println(num==mynum);
	  
	  System.out.println(num==value);
	  
	  System.out.println(num.equals(value));
	  
	  System.out.println(mynum==myvalue);
	  
	  System.out.println(mynum.equals(myvalue));
		
	}

}
