package day6demo;

import java.time.format.DateTimeFormatter;
import java.util.Date;

public class formatchange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Date  d= new Date();
		
		
		DateTimeFormatter ft=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		
	
		
	}

}
