package day6demo;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NormalInnerClass.innercl obj=new NormalInnerClass().new innercl();
		
		NormalInnerClass objt=new NormalInnerClass();
		
		
		
		obj.show();
				
		objt.print();
		
	}

}
