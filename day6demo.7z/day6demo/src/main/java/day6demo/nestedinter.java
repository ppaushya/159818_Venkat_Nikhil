package day6demo;

public interface nestedinter {

	void draw();
	
	public interface innerinter
	{
		void fillcolor();
	}
	
	
	
}
