package day6demo;

public class outerclass {

	String name="nikhil";
	
	public void details()
	{
		int count=100;
		//method local inner classes
		class temp
		{
			int num=45;
			String name="venkat";
			
			public void printt()
			{
				outerclass obj=new outerclass();
				
				System.out.println(num);
				System.out.println(count);
				System.out.println(obj.name);
				
				
			}
			
			
		
			
		}
		temp objj=new temp();
		objj.printt();
	}
	
}
