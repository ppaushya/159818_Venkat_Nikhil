package day6demo;

public class staticnestedClass {

	int count=100;
	
	static float pi=3.14f;
	
	public static class innerclass
	{
		
		int num=100;
		
		public void print()
		{
			System.out.println(num);
			// System.out.println(count);
			System.out.println(pi);
			show();
		}
		
		public static void show()
		{
			System.out.println("show method inner class");
		}
		
		
	}
	
	
	public static void show()
	{
		System.out.println("show method outer class");
	}
	
	
}
