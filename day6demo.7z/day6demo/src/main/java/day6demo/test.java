package day6demo;

 //import static org.cap.nikhil.staticnestedclass.*;



public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
