package day6demo;

public class testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		staticnestedClass.innerclass.show();
		
		staticnestedClass.innerclass obj= new staticnestedClass.innerclass();
		
		obj.print();
		
		
	}

}
