package day6demo;

public class wrapperClass {

	public static void main(String[] args) {
		
		
		Integer integer=new Integer(23);
		
		int num=100;
		
		integer=num;
		
		System.out.println(integer);
		
		
		System.out.println(integer.MAX_VALUE+" , "+integer.MIN_VALUE);
		
		
		System.out.println(Short.MAX_VALUE+" , "+Short.MIN_VALUE);
		
		System.out.println(Double.MIN_NORMAL+" , "+Double.MAX_VALUE+" , "+Double.MIN_VALUE+" , "+Double.MAX_EXPONENT);
		
	
		String str="123";
		
		System.out.println(Integer.parseInt(str));
		
		//System.out.println(num.doubleValue());
		
		
		
		
	}

}
