package day7demos;

public class InvalidAgeException extends RuntimeException {



		public InvalidAgeException(String str)
		{
			super(str);
		}
		
	}


