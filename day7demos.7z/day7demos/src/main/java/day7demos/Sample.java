package day7demos;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String num=null;
		
		if(num!=null)
		{
			int n=Integer.parseInt(num);
			int ans=n+90;
			System.out.println("ans is "+ans);
		}
		
		else
		{//try
		   //{
			throw new NullPointerException("hey sorry null here ! i cant process");
		   //}
		//catch(NullPointerException e)
		//{
			//e.getMessage();
		//}
		}
		
		System.out.println("execution completed");
	}

}
