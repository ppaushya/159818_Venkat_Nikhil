package day7demos;

public class checkexception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		int num1=100;
		int result=0;
		
		String num2="12s";
		//risky block may be executed but finally block will be mandatorily executed
		//int num2=0;
		try
		{
		 result=num1/(Integer.parseInt(num2));
		}
		catch(ArithmeticException e)
		{
	    System.out.println(e.getMessage());
		e.printStackTrace();
		
		}
		catch(NumberFormatException d)
		{
			System.out.println(d.getMessage());
			d.printStackTrace();
		}
		finally
		{
			//100% this will be executed
			System.out.println("finally block statement");
		}
		
		System.out.println(result);
		
		
	}

}
