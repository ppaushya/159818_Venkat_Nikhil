package day7demos;

import java.io.FileNotFoundException;

public class child extends parent implements shape {

	@Override
	public void print() throws FileNotFoundException,InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("print method child class");
	}

	public void draw() throws FileNotFoundException
	{
		
	}
	
	
}
