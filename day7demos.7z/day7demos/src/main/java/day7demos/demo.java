package day7demos;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer num1=100;
		Integer num2=2;
		Integer ans=null;
		try
		{
		 ans=num1+num2;
			System.out.println("answer is "+ans);
	     
		   try
		   {
			   String num="8s";
			int result=ans/Integer.parseInt(num);
			System.out.println("result is "+result);
		   }
		   catch(NullPointerException e)
		   {
			   e.printStackTrace();
		   }
		   System.out.println("inner try and catch block");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
