package day7demos;

public class mainclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		calculation c = new calculation();
		
		//c.calculate();
		
	}

}
