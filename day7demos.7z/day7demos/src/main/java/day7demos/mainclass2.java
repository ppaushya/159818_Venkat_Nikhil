package day7demos;

public class mainclass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		int age=12;
		
		if(age<=18)
		{
			throw new InvalidAgeException("sorry u have less than 18 years");
		}
     
     
	}

}
