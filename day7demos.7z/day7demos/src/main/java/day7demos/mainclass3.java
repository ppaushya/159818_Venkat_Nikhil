package day7demos;

public class mainclass3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      child obj=new child();
     try
     {
      obj.print();
     }
     catch(Exception e)
     {
    	 e.printStackTrace();
     }
	}

}
