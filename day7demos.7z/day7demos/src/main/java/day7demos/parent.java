package day7demos;

import java.io.FileNotFoundException;

public class parent {

	public void print() throws FileNotFoundException,InterruptedException
	{
	 	System.out.println("hello !");
	}
	
}
