package day7demos;

import java.io.FileNotFoundException;

public interface shape {

	public void draw() throws FileNotFoundException;
	
}
