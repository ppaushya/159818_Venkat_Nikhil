package day7demos;

import java.io.File;
import java.io.FileInputStream;

public class testclass {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
      File file=new File("c:\\sample\\data.txt");
      //try
     // {
      FileInputStream inputstream=new FileInputStream(file);
      //}
      //catch(Exception e)
      //{
    	//  System.out.println("file not found exception");
      //}
	}

}
