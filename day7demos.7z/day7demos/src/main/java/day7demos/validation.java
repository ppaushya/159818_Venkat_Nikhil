package day7demos;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class validation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String empid;
		
		Scanner  s= new Scanner(System.in);

		empid=s.next();
		
       if(empid.matches("\\d{5}_(FS|TS|IN)"))
       {
    	   System.out.println("valid");
       }
       else
       {
    	   System.out.println("try for one more tiem");
       }
       
       
       Pattern pattern=Pattern.compile("\\d{5}_(FS|TS|IN)");
       
       Matcher matcher=pattern.matcher(empid);
       
       System.out.println(matcher.find());
       
       
	}

}
