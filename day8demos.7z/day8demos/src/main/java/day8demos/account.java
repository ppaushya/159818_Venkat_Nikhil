package day8demos;

import java.time.LocalDate;

public class account {

	private int accno;
	
	private String acctype;
	
	//private LocalDate openingdate;
	
	private float balance;
	
	

	public int getAccno() {
		return accno;
	}

	public account(int accno, String acctype, float balance) {
		super();
		this.accno = accno;
		this.acctype = acctype;
		this.balance = balance;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getAcctype() {
		return acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	
	public account()
	{
		
	}
}
