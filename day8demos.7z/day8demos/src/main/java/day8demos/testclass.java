package day8demos;

import java.util.ArrayList;
import java.util.List;

public class testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<account> accounts=new ArrayList<>();
		
		accounts.add(new account(100,"savings",1000));
		
		for(account ac:accounts)
		{
			System.out.println(ac.getAccno() + ac.getAcctype());
		}
		
	}

}
