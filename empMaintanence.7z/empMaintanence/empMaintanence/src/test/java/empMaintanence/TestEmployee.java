package empMaintanence;

import java.time.LocalDate;

import org.empMaintanence.dao.LoginDaoImpl;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.service.LoginServicesImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.cglib.core.EmitUtils;



class TestEmployee {

	
	@Mock
    private LoginDaoImpl logindao;
	
	private LoginServicesImpl loginservices;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		//demanddraftservice = new DemandDraftService(demanddraftdao);
		loginservices= new LoginServicesImpl(logindao);
	}
	

	
	@Test
	public void test_acc_with_allvalid_format()
	{
	    /*
	    UserMaster user=new UserMaster();
	    
	   user.setUserId("100003");
	   
	   user.setUserName("david");
	   
	   user.setUserPassword("ddavid21996");
	   
	   user.setUserType("employee");
	   
	    */
		
		Employee employee=new Employee();
		employee.setEmpId("100001");
		employee.setEmpFirstName("sunny");
		employee.setEmpLastName("sunny");
		employee.setEmpDateOfBirth(LocalDate.now());
		employee.setEmpDateOfJoining(LocalDate.now());
		employee.setEmpDeptId(1);
		employee.setEmpGrade("M1");
		employee.setEmpDesignation("analyst");
		employee.setEmpBasic(10000);
		employee.setEmpGender("M");
		employee.setEmpMaritalStatus("M");
		employee.setEmpHomeAddress("chennai");
		employee.setEmpContactNo("7989499127");
		
	    
	    Mockito.when(logindao.addEmployeeDetails(employee)).thenReturn(1);
	    
	    loginservices.addEmployeeDetails(employee);
	    
	   // demanddraftservice.addDemandDraftDetails(demand);
	    
	    Mockito.verify(logindao).addEmployeeDetails(employee);
	    
	    
	}
	
	
	
}
