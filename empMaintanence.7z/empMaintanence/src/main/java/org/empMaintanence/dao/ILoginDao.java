package org.empMaintanence.dao;

import java.util.List;

import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public interface ILoginDao {

	int validlogin(UserMaster usermaster);

	public void addEmployeeDetails(Employee employee);

	void modifyfirstname();

	List<Employee> findBasedOnId(String userId);
	public List<Department> displayDepartmentList();

	List<Employee> displayEmployeesList();

	List<Employee> findBasedOnFirstName(String userId);

	List<Employee> findBasedOnLastName();

	List<Employee> findBasedOnDepartment();

	List<Employee> findBasedOnGrade();

	List<Employee> findBasedOnMaritalStatus();

}
