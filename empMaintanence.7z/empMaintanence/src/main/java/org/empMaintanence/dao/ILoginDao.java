package org.empMaintanence.dao;

import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public interface ILoginDao {

	boolean validlogin(UserMaster usermaster);

	void addemployee(Employee employee);

}
