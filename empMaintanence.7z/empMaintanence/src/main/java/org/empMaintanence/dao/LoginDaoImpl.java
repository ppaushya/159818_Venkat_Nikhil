package org.empMaintanence.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.empMaintanence.model.UserMaster;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		
		
		if(usermaster.getUserType().compareTo("admin")==0 || usermaster.getUserType().compareTo("ADMIN")==0 )
		{
			if(usermaster.getUserId().compareTo("100")==0 && usermaster.getUserName().compareTo("mainadmin")==0 && usermaster.getUserPassword().compareTo("admin123")==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(usermaster.getUserType().compareTo("employee")==0 || usermaster.getUserType().compareTo("EMPLOYEE")==0 )
		{
		   	 
		}
				
		return false;
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/casestudy", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

}
