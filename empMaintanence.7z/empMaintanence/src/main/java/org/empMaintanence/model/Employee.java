package org.empMaintanence.model;

import java.time.LocalDate;

public class Employee {

	/*
	 * 
	 * iii.	Employee:Emp_ID VARCHAR2(6), Emp_First_Name VARCHAR2(25),
	 *  Emp_Last_Name VARCHAR2(25), Emp_Date_of_Birth DATE,Emp_Date_of_Joining DATE, 
	 *  Emp_Dept_ID int, Emp_Grade VARCHAR2(2),
	 *   Emp_Designation VARCHAR2(50), Emp_Basic int,
	 *    Emp_Gender VARCHAR2(1), Emp_Marital_Status VARCHAR2(1), 
	 * Emp_Home_Address VARCHAR2(100), Emp_Contact_Num VARCHAR2(15)
	 */
	
	private String empId;
	
	private String empFirstName;
	
	public Employee(String empFirstName, String empLastName, LocalDate empDateOfBirth, LocalDate empDateOfJoining,
			int empDeptId, String empGrade, String empDesignation, int empBasic, String empGender,
			String empMaritalStatus, String empHomeAddress, String empContactNo) {
		super();
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
	}

	private String empLastName;
	
	private LocalDate empDateOfBirth;
	
	private LocalDate empDateOfJoining;
	
	private int empDeptId;
	
	private String empGrade;
	
	private String empDesignation;
	
	private int empBasic;
	
	private String empGender;
	
	private String empMaritalStatus;
	
	private String empHomeAddress;
	
	private String empContactNo;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public LocalDate getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(LocalDate empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public LocalDate getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(LocalDate empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public int getEmpDeptId() {
		return empDeptId;
	}

	public void setEmpDeptId(int empDeptId) {
		this.empDeptId = empDeptId;
	}

	public String getEmpGrade() {
		return empGrade;
	}

	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getEmpContactNo() {
		return empContactNo;
	}

	public void setEmpContactNo(String empContactNo) {
		this.empContactNo = empContactNo;
	}

	public Employee(String empId, String empFirstName, String empLastName, LocalDate empDateOfBirth,
			LocalDate empDateOfJoining, int empDeptId, String empGrade, String empDesignation, int empBasic,
			String empGender, String empMaritalStatus, String empHomeAddress, String empContactNo) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateOfBirth = empDateOfBirth;
		this.empDateOfJoining = empDateOfJoining;
		this.empDeptId = empDeptId;
		this.empGrade = empGrade;
		this.empDesignation = empDesignation;
		this.empBasic = empBasic;
		this.empGender = empGender;
		this.empMaritalStatus = empMaritalStatus;
		this.empHomeAddress = empHomeAddress;
		this.empContactNo = empContactNo;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empDateOfBirth=" + empDateOfBirth + ", empDateOfJoining=" + empDateOfJoining + ", empDeptId="
				+ empDeptId + ", empGrade=" + empGrade + ", empDesignation=" + empDesignation + ", empBasic=" + empBasic
				+ ", empGender=" + empGender + ", empMaritalStatus=" + empMaritalStatus + ", empHomeAddress="
				+ empHomeAddress + ", empContactNo=" + empContactNo + "]";
	}
	
	
	
	
	
}



