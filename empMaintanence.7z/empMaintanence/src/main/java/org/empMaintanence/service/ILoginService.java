package org.empMaintanence.service;

import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public interface ILoginService {

	boolean validlogin(UserMaster usermaster);

	void addemployee(Employee employee);

	
	
	
}
