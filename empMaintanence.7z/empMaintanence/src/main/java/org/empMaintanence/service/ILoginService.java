package org.empMaintanence.service;

import org.empMaintanence.model.UserMaster;

public interface ILoginService {

	boolean validlogin(UserMaster usermaster);

	
	
	
}
