package org.empMaintanence.service;

import org.empMaintanence.dao.ILoginDao;
import org.empMaintanence.dao.LoginDaoImpl;
import org.empMaintanence.model.UserMaster;

public class LoginServicesImpl implements ILoginService  {

	ILoginDao logindao=new LoginDaoImpl();
	
	@Override
	public boolean validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		return logindao.validlogin(usermaster);
		
		
	}

}
