package org.empMaintanence.service;

import org.empMaintanence.dao.ILoginDao;
import org.empMaintanence.dao.LoginDaoImpl;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public class LoginServicesImpl implements ILoginService  {

	ILoginDao logindao=new LoginDaoImpl();
	
	@Override
	public boolean validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		return logindao.validlogin(usermaster);
		
		
	}

	@Override
	public void addEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
	      logindao.addEmployeeDetails(employee);
	}

	@Override
	public void modifyfirstname() {
		// TODO Auto-generated method stub
		logindao.modifyfirstname();
	}

}
