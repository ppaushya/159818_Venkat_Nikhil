package org.empMaintanence.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public class UserInteraction {

	Scanner scanner=new Scanner(System.in);

	
	public UserMaster getLoginDetails() {
		
		
		System.out.println("Welcome to the Employeement maintanence system");
		
		
		System.out.println("Enter the login details");
		
		System.out.println("Enter the User Id");
		
		String userId=scanner.next();
		
		System.out.println("Enter the User Name");
		
		String userName=scanner.next();
		
		System.out.println("Enter the User Password");
		
		String userPw=scanner.next();
		
		System.out.println("Enter the user type");
		
		String userType=scanner.next();
		
		
UserMaster usermaster=new UserMaster();
		
		usermaster.setUserId(userId);
		
		usermaster.setUserName(userName);
		
		usermaster.setUserPassword(userPw);
		
		usermaster.setUserType(userType);
		
		
		
		return usermaster;
	}

	public Employee getEmployeeDetails() {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the employee details");
		
		System.out.println("Enter the first name");
		
		Employee employee=new Employee();
		
		employee.setEmpFirstName(scanner.next());
		
		System.out.println("Enter the last name");
		
		employee.setEmpLastName(scanner.next());
		
		System.out.println("Enter the Date of birth[dd-mm-yyyy]");
		
		String dob=scanner.next();
		
		String date1[]=dob.split("-");
		
		employee.setEmpDateOfBirth(LocalDate.of(Integer.parseInt(date1[2]), Integer.parseInt(date1[1]), Integer.parseInt(date1[0])));
		
		employee.setEmpDateOfJoining(LocalDate.now());
		
		System.out.println("Enter the department id ");
		
		employee.setEmpDeptId(scanner.nextInt());
		
		System.out.println("Enter the employee grade ");
		
		employee.setEmpGrade(scanner.next());

		System.out.println("Enter the designation of the employee");
		
		employee.setEmpDesignation(scanner.next());
		
		System.out.println("Enter the employee basic");

		employee.setEmpBasic(scanner.nextInt());
		
		System.out.println("Enter the employee gender");
		
		employee.setEmpGender(scanner.next());
		
		System.out.println("Enter the employee marital status");
		
		employee.setEmpMaritalStatus(scanner.next());

		System.out.println("Enter the employee home address");
		
		employee.setEmpHomeAddress(scanner.next());
		
		System.out.println("Enter the employee contact no");
		
		employee.setEmpContactNo(scanner.next());
		
		
		
		
		System.out.println("");
		return employee;
	}

}
