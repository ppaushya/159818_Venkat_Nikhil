package org.empMaintanence.view;

import java.time.LocalDate;

public class Utility {

	public static boolean isValidEmpId(String empId) {
		return empId.matches("[1-9][0-9]{5}");

	}

	public static boolean isValidFirstName(String fname) {
		
		return fname.matches("[A-Za-z]{1,}");
	}

	public static boolean isValidLastName(String lname) {
		
		return lname.matches("[A-Za-z]{1,}");
	}

	public static boolean isValidDateOfBirth(String dob) {
		
		return dob.matches("[0-3][0-9]-[A-Za-z]{3}-[0-9][0-9]");
	}

	public static boolean isValidDesignation(String design) {
		
		return design.matches("[A-Za-z]+");
	}

	public static boolean isValidHomeAddress(String address) {
		
		return address.matches("[A-Za-z0-9\\s]*");
	}

	public static boolean isValidContactNumber(String contactNo) {
		
		return contactNo.matches("[A-Za-z0-9\\s]*");
	}
}
