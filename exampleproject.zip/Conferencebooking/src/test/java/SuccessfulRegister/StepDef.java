package SuccessfulRegister;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
private WebDriver webdriver;
	
	private WebElement webelement,element;
	
	@Before
	public void setup()
	{
System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		webdriver=new ChromeDriver();
		
	}
	

@Given("^open conferencebooking login page$")
public void open_conferencebooking_login_page() throws Throwable {
 
	webdriver.get("http://localhost:8080/Conferencebooking/");
	
}

@When("^not provide valid title details$")
public void not_provide_valid_title_details() throws Throwable {
 
	if(webdriver.getTitle().compareTo("Conference Registration")!=0)
	{
		System.out.println(webdriver.getTitle());
	    webdriver.quit();
	}
	
	
}

@Then("^stop the execution$")
public void stop_the_execution() throws Throwable {
   
}


@Given("^open conferencebook login page$")
public void open_conferencebook_login_page() throws Throwable {
	webdriver.get("http://localhost:8080/Conferencebooking/");
}

@When("^provide valid title$")
public void provide_valid_title() throws Throwable {
    
	
}

@When("^invalid heading$")
public void invalid_heading() throws Throwable {
    // Write code here that turns the phrase above into concrete actions

	System.out.println(webdriver.findElement(By.tagName("h4")).getText());
	if(webdriver.findElement(By.tagName("h4")).getText().compareTo("Step 1: Personal Details")==0)
	{
	}
	else
	{
		webdriver.quit();
	}



}

@Then("^stops the execution$")
public void stops_the_execution1() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}



@Given("^provide valid titles$")
public void provide_valid_titles() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	webdriver.get("http://localhost:8080/Conferencebooking/");
}

@Given("^valid headings$")
public void valid_headings() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  
}

@Given("^registration details$")
public void registration_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  if(webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"))!=null)
	  System.out.println("TRUE");
  else
	  System.out.println("FALSE");
}

@When("^invalid registration details$")
public void valid_registration_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}

@Then("^navigate to payments page$")
public void navigate_to_payments_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}


@Given("^provide register details$")
public void provide_register_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	webdriver.get("http://localhost:8080/Conferencebooking/");

}

@When("^valid details$")
public void valid_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
	webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("");
	webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
	Alert alert=webdriver.switchTo().alert();
	System.out.println(alert.getText());
	
	if(alert.getText().compareTo("Please fill the First Name")==0)
	{
		webdriver.switchTo().alert().accept();
		webdriver.get("http://localhost:8080/Conferencebooking/");
		webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("sid");
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
		alert=webdriver.switchTo().alert();
		if(alert.getText().compareTo("Please fill the Last Name")==0)
		{
			webdriver.switchTo().alert().accept();
            webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("jerry");
            webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
    		alert=webdriver.switchTo().alert();
    		
    		if(alert.getText().compareTo("Please fill the Email")==0)
    		{
    			webdriver.switchTo().alert().accept();
    			webdriver.findElement(By.xpath("//*[@id=\"txtEmail\"]")).sendKeys("sid@gmail.com");
    			  webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
    	    		alert=webdriver.switchTo().alert();
    	       if(alert.getText().compareTo("Please fill the Contact No.")==0)
    	       {
    	    	   webdriver.switchTo().alert().accept();
    	    	   webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("7821bnb");
    	    	   webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
   	    		alert=webdriver.switchTo().alert();
   	    		
   	    		if(alert.getText().compareTo("Please enter valid Contact no.")==0)
   	    		{
     	    	   webdriver.switchTo().alert().accept();

     	    		 webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).clear();

   	    		 webdriver.findElement(By.xpath("//*[@id=\"txtPhone\"]")).sendKeys("7989499127");
   	    		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
   	    		alert=webdriver.switchTo().alert();
   	    		 
   	    		}
    	    	   
    	    	   
    	       }
    		}
    			
    			
    		
		}
	}
	
}

@Then("^navigate to success page$")
public void navigate_to_success_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
}




}
