package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Customers;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		
		String username=req.getParameter("email");
		
		String password=req.getParameter("custPwd");
		
		String cnfrmpw=req.getParameter("confimrCustPwd");
		
		
		Customers cust=new Customers();
		cust.setUserName(username);
		cust.setUserPwd(password);
		
		if(loginService.addcustomer(cust))
		{
		resp.sendRedirect("index.html");
		}
		else
		{
			PrintWriter out=resp.getWriter();
			out.println("iam not a foodpanda or zomato DBA to allow my users to create multiple accounts..u already have a account here");
		}
	}
	
}
