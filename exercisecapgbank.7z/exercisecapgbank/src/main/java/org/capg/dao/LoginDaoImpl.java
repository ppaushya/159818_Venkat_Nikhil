package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capg.model.Customers;
import org.capg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customers";
		
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement pst=conn.prepareStatement(sql);
				
				ResultSet res=pst.executeQuery();
				
				while(res.next())
				{
					if(res.getString(1).compareTo(loginBean.getUserName())==0 && res.getString(2).compareTo(loginBean.getUserPassword())==0) {
						{
							return true;
						}
					}
				}
				
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/customer", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/customer", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	

	@Override
	public boolean addcustomer(Customers cust) {
		// TODO Auto-generated method stub
		String sql="insert into customers values(?,?)";
		String sql1="select * from customers";

		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
			PreparedStatement pst1=conn.prepareStatement(sql1);

			  ResultSet res=pst1.executeQuery();
			  boolean flag=true;
			  while(res.next())
			  {
				  if(res.getString(1).compareTo(cust.getUserName())==0)
				  {
					  flag=false;
					  return false;
				  }
			  }
			
			
			  if(flag)
			  {
				PreparedStatement statement=conn.prepareStatement(sql);
				
				statement.setString(1, cust.getUserName());
				statement.setString(2, cust.getUserPwd());
				
				int count=statement.executeUpdate();
				return true;
			  }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
return true;
}
}