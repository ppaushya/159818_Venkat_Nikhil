package org.capg.model;

public class Customers {

	String userName;
	
	String userPwd;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public Customers(String userName, String userPwd) {
		super();
		this.userName = userName;
		this.userPwd = userPwd;
	}

	public Customers() {
		super();
	}

	@Override
	public String toString() {
		return "Customers [userName=" + userName + ", userPwd=" + userPwd + "]";
	}
	
	
	
}
