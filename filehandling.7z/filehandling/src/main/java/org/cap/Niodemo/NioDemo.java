package org.cap.Niodemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;

public class NioDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

   File src=new File("C:\\demo\\filedemo\\DemoBufferReader.java");	
   
   File dest=new File("C:\\demo\\filedemo\\destination.txt");
   FileInputStream in;
   FileOutputStream out;
   
   try {
	in = new FileInputStream(src);
	out = new FileOutputStream(dest);
	
	
	ReadableByteChannel reader=in.getChannel();
	
	WritableByteChannel writer=out.getChannel();
	
	//ByteBuffer buffer=buffer.allocate(100);
	
	/*
	while(reader.read(dst))
	{
		buffer.flip();
		
		while(buffer.hasRemaining())
		{
			
		}
	}
	*/
	
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
   
   
		
	}

}
