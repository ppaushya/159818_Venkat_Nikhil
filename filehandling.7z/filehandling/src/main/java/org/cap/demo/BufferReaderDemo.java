package org.cap.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;

public class BufferReaderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		FileReader in;
		try {
			in = new FileReader("C:\\demo\\filedemo\\mydemo.txt");
			BufferedReader reader=new BufferedReader(in); 
			
			String line=reader.readLine();
			
			System.out.println(line);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
