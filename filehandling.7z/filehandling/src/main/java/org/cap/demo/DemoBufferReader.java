package org.cap.demo;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoBufferReader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream in;
		try {
			File file=new File("C:\\demo\\filedemo\\mydemo.txt");
			in = new FileInputStream(file);
			BufferedInputStream inputstream=new BufferedInputStream(in);
			int mybyte=inputstream.read();
			
			while(mybyte!=-1)
			{
			System.out.println((char)mybyte);
			mybyte=inputstream.read();
			}
			
			byte[] arr=new byte[100];
					//inputstream.read(arr);
					inputstream.read(arr);
					
					for(byte ch:arr)
					{
						System.out.println((char)ch);
					}
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
       
	}

}
