package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class Filedemo {

	public static void main(String[] args) throws IOException {
		
		File file=new File("C:\\demo\\filedemo\\mydemos.txt");
		
		//file.delete();
		
		if(file.isFile())
		{
		if(file.exists())
		{
			System.out.println("Readable : "+file.canRead());
			System.out.println("writable : "+file.canWrite());
			System.out.println("Readable : "+file.canRead());
				System.out.println("path : "+file.getAbsolutePath());
			
		}
		else
		{
			System.out.println("file doesnt exist");
		}
		}
		else if(file.isDirectory())
		{
			String[] name=file.list();
			
			for(String names:name)
			{
				System.out.println(names);
			}
			
		}
		else
		{
			System.out.println("no file/directory exists");
			file.createNewFile();
		}
		
		System.out.println("free space :"+file.getFreeSpace());
		System.out.println("total space :"+file.getTotalSpace());
		System.out.println("usable space :"+file.getUsableSpace());
	}

}
