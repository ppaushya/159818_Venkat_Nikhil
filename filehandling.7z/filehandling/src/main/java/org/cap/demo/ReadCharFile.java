package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadCharFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file=new File("C:\\demo\\filedemo\\mydemo.txt");
		
		FileReader reader=new FileReader(file);
		
		int ch=reader.read();
		
		while(ch!=-1)
		{
		System.out.println((char)ch);
		ch=reader.read();
		}	
		
	}

}
