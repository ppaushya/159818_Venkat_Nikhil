package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharFile {

	public static void main(String[] args) throws IOException  {
		// TODO Auto-generated method stub
File file=new File("C:\\demo\\filedemo\\mydemo.txt");

FileReader reader=new FileReader(file);

int ch=reader.read();
int k=1;

char arr[]=new char[100];
arr[0]=(char)ch;


while(ch!=-1)
{
	System.out.println((char)ch);
	ch=reader.read();
	arr[k]=(char)ch;
	k++;
}




System.out.println();
for(int i=k-2;i>=0;i--)
{
	System.out.print(arr[i]);
}



/*
	try(FileWriter writer = new FileWriter(file)) {

		String greetings="good afternoon";
		
		char ch[]=greetings.toCharArray();
		
		for(char c:ch)
		{
			writer.write(c);
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	*/
	}

}
