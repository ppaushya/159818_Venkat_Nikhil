package org.cap.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class distreamexercise {

	public static void main(String[] args) {
		
		File file=new File("C:\\demo\\filedemo\\mydemo.txt");
		
		try {
			FileOutputStream outstream=new FileOutputStream(file);
			DataOutputStream obj=new DataOutputStream(outstream);
			String str="nikhil";
			int count=str.length();
			obj.writeInt(100);
			obj.write(str.getBytes());
			obj.write(10);
			
			obj.writeInt(100);
			obj.write(str.getBytes());
			obj.write(10);
			
			obj.writeInt(100);
			obj.write(str.getBytes());
			obj.write(10);
			
			
			
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		try {
			FileInputStream inputstream=new FileInputStream(file);
		//	DataInputStream 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
