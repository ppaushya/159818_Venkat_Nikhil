package org.gaming.services;

import org.gaming.Dao.CustomerDaoImpl;


import org.gaming.Dao.ICustomerDao;
import org.gaming.exceptions.InvalidCustomerException;
import org.gaming.model.Registration;
import org.gaming.util.Utility;

import org.apache.log4j.Logger;

import org.apache.log4j.pattern.*;



public class CustomerServicesImpl implements ICustomerServices{

	ICustomerDao customerDao= new CustomerDaoImpl();
   final static Logger logger=Logger.getLogger(CustomerServicesImpl.class);
   
   public CustomerServicesImpl(ICustomerDao customerDao2) {
	// TODO Auto-generated constructor stub
	   this.customerDao=customerDao2;
}




public CustomerServicesImpl() {
	super();
}




public void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("This is debug: "+parameter);
		}
		
		if(logger.isInfoEnabled())
		{
			logger.info("This is info: "+parameter);
		}
		
		logger.warn("This is warn: "+parameter);
		logger.error("This is error: "+parameter);
		logger.fatal("This is fatal: "+parameter);
	}
   
   
	@Override
	public boolean doCustomerRegistration(Registration registration) throws InvalidCustomerException {
		// TODO Auto-generated method stub
		//validate customer
		
		if(Utility.isvalidcustomer(registration))
		{
 		customerDao.doCustomerRegistration(registration);
 		return true;
		}
		else
		{
	       logger.error("customer is invalid");	
			throw new InvalidCustomerException("details not in proper format..so account cant be created");
			
		}
		
	}

	
	
	
	
}
