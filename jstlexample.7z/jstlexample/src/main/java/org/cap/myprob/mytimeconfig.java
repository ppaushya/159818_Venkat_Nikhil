package org.cap.myprob;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class mytimeconfig extends SimpleTagSupport{
	
	private String printtime;
	
	private String user;
	
	
	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPrinttime(String printtime) {
		this.printtime = printtime;
	}

	public void setTimeFormat(String timeFormat) {
		this.timeFormat = timeFormat;
	}

	private String timeFormat;
	
	



	@Override
	public void doTag() throws JspException, IOException {
		
		
		JspWriter out= getJspContext().getOut();
		
	LocalTime time=java.time.LocalTime.now();
		
	if(time.isAfter(java.time.LocalTime.of(9, 0, 0)) && time.isBefore(java.time.LocalTime.of(12,0,0)))
	{
		if(user!=null)
		{
			out.println("<h4>good morning <span style='color:red;'>" + user +"</span></h4>");
		}
		else
		{
			out.println("<h4>good morning <span style='color:red;'>" + "capg" +"</span></h4>");
	
		}
	}
	
	else if(time.isAfter(java.time.LocalTime.of(12, 0, 0)) && time.isBefore(java.time.LocalTime.of(13,30,0)))
	{
		if(user!=null)
		{
			out.println("<h4>good afternoon <span style='color:red;'>" + user +"</span></h4>");
		}
		else
		{
			out.println("<h4>good afternoon <span style='color:red;'>" + "capg" +"</span></h4>");
	
		}
		
	}
	else if(time.isAfter(java.time.LocalTime.of(13, 31, 0)) && time.isBefore(java.time.LocalTime.of(22,0,0)))
	{
		if(user!=null)
		{
			out.println("<h4>good evening <span style='color:red;'>" + user +"</span></h4>");
		}
		else
		{
			out.println("<h4>good evening <span style='color:red;'>" + "capg" +"</span></h4>");
	
		}
		
	}
	
	
}
}
