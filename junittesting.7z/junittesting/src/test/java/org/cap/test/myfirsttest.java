package org.cap.test;

import static org.junit.Assert.*;

import org.cap.demo.calculate;
import org.junit.Test;

public class myfirsttest {

	@Test
	public void test_addNumber_method() {
//		fail("Not yet implemented");
		
		calculate cal=new calculate();
	
		assertEquals(15, cal.addNumber(5, 10));
	
	}

}
