package org.capg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.springframework.stereotype.Repository;

@Transactional
@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public boolean addAccount(Account account) {
		
		em.persist(account);
		
		return true;
	}


	@Override
	public List<Transaction> getTransaction(Account fromAccount) {
		// TODO Auto-generated method stub
		Query query=em.createQuery("from Transaction where fromAccount_accountNumber=:fromAccount");
		List<Transaction> transactionList=query.setParameter("fromAccount", fromAccount.getAccountNumber()).getResultList();
		return transactionList;
	}


	@Override
	public Boolean addTransaction(Transaction transaction) {
		em.persist(transaction);
		return true;
	}


	@Override
	public List<Account> getAccounts(Customer customer) {
		System.out.println(customer);
		Query query=em.createQuery("from Account where customer_customerId=:c");
		List<Account> accountList=query.setParameter("c", customer.getCustomerId()).getResultList();
		return accountList;
	}


	@Override
	public List<Account> getOtherAccounts(Customer customer) {
		System.out.println(customer);
		Query query=em.createQuery("from Account where customer_customerId<>:c");
		List<Account> accountList=query.setParameter("c", customer.getCustomerId()).getResultList();
		return accountList;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
