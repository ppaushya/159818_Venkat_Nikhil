package org.capg.dao;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public interface IAccountDao {

	public boolean addAccount(Account account);

	public List<Transaction> getTransaction(Account fromAccount);

	public Boolean addTransaction(Transaction transaction);

	public List<Account> getAccounts(Customer customer);

	public List<Account> getOtherAccounts(Customer customer);
	
}
