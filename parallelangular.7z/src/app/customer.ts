export class Customer{
  emailId : string;
  customerPwd : string;
  firstName : string;
  lastName : string;
  dateOfBirth : string;
  customerId : number;
  mobile : string;



}

