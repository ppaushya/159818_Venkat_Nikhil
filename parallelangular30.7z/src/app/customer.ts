export class Customer{
  emailId : string;
  customerPwd : string;
  firstName : string;
  lastName : string;
  dateOfBirth : string;
  customerId : number;
  mobile : string;
  addressline1 : string;
  addressline2 : string;
  city : string;
  state : string;
  pincode : string;
}

