import { Component, OnInit } from '@angular/core';
import {Customer} from '../customer';
import {CustService} from '../cust.service';
import { Observable } from 'rxjs';
import { RouterModule, Router } from '@angular/router';
@Component({
  //selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {



  constructor(private custService: CustService,private router: Router) { 

  }

  cust : Customer;

  customer : Customer={
    emailId : "",
  customerPwd : "",
  firstName : "",
  lastName : "",
  dateOfBirth : "",
  customerId :0,
  mobile : ""
};

  ngOnInit() {
  }


  getCustomers(customer : Customer) {
    this.custService.getCustomers(customer).subscribe(customer=>{if(customer==null)
    {
    
          this.router.navigate(['../registration'])
    }
    else{
      console.log("hiiii" + customer.firstName)

     this.router.navigate(['../mainpage'])
    } });


   /*
   if(this.customer==null)
   {
         this.router.navigate(['../registration'])
   }
   else{
    this.router.navigate(['../mainpage'])
   }
*/
  }



}
