import { Component, OnInit } from '@angular/core';
import { Address } from '../address';
import {Customer} from '../customer'
import {CustService} from '../cust.service';
import { RouterModule, Router } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private custService: CustService,private router: Router) { 

  }

  register : Address={
    addressId : 0 ,
    addressLine1 : "",
    addressLine2 : "",
    city : "",
    state : "",
    pincode :""

  };
  
  customer1 : Customer={
    emailId : "",
  customerPwd : "",
  firstName : "",
  lastName : "",
  dateOfBirth : "",
  customerId :0,
  mobile : ""
};

  ngOnInit() {
  }

  createCustomers(customer : Customer,register : Address)  {
    this.custService.createCustomers(customer,register).subscribe(cust=>this.customer1=cust);
}

}
