package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;


public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		
String sql="select * from customers";
		
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement pst=conn.prepareStatement(sql);
				
				ResultSet res=pst.executeQuery();
				
				while(res.next())
				{
					if(res.getString(2).compareTo(loginBean.getUserName())==0 && res.getString(3).compareTo(loginBean.getUserPassword())==0) {
						{
							return true;
						}
					}
				}
				
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/customer", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customers(emailId,customerPwd)"+
						" values(?,?)";
		
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
		
		
		pst.setString(1, customer.getEmailId());
		pst.setString(2,customer.getCustomerPwd());	
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}



private Connection getDbConnection() {
	Connection connection=null;
	try{	
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection
				("jdbc:mysql://localhost:3306/customer", "root", "India123");
		return connection;
	}catch (ClassNotFoundException|SQLException e) {
		e.printStackTrace();
	}
	
	return null;
	
}


@Override
public boolean createaccount(Account acc,String mailid) {
	// TODO Auto-generated method stub
	
	int custid=0;
	
	String sql="insert into account(acctype,openingdate,openingbalance,description,cstid) values(?,?,?,?,?) ";
	String sql1="select * from customers";
	String sql2="select * from account";
	String sql3="select * from account where cstid=?";
			
try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
		
	PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sql1);
	
	ResultSet res=pst1.executeQuery();
	
	while(res.next())
	{
		if(res.getString(2).compareTo(mailid)==0)
		{
			custid=res.getInt(1);
		}
	}
	
	
	PreparedStatement pst3=getMysqlDbConnection().prepareStatement(sql3);
	pst3.setInt(1, custid);
	
	ResultSet res3=pst3.executeQuery();
	
	while(res3.next())
	{
		if(res3.getString(2).compareTo(acc.getAccountType())==0)
		{
			return false;
		}
	}
	
	
	
	
	pst.setString(1, acc.getAccountType());
	pst.setDate(2, Date.valueOf(acc.getOpeningDate()));
	pst.setDouble(3, acc.getOpeningBalance());
	pst.setString(4, acc.getDescription());
	pst.setInt(5, custid);
	int count=pst.executeUpdate();
	if(count>0)
		return true;

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	return false;
}


@Override
public List<Account> getAllAccounts(String mailid) {
	// TODO Auto-generated method stub
	
	List<Account> accounts=new ArrayList<>();
	
	int custid=0;
	
	String sql="select * from account";
	
	String sql1="select * from customers";
	
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
		
		PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sql1);
		
		ResultSet res=pst1.executeQuery();
		
		while(res.next())
		{
			if(res.getString(2).compareTo(mailid)==0)
			{
				custid=res.getInt(1);
				System.out.println(custid);
			}
		}
		
		
		ResultSet res1=pst.executeQuery();
		
		while(res1.next())
		{
			if(res1.getInt(6)==custid)
			{
				Account acc=new Account();
				acc.setAccountNumber(res1.getInt(1));
			acc.setAccountType(res1.getString(2));
			//	acc.setOpeningDate(res1.getDate(3).toLocalDate());
				//acc.setOpeningBalance(res.getDouble(4));
				//acc.setDescription(res.getString(5));
			
				System.out.println(acc);
				accounts.add(acc);
			}
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	
	return accounts;
	
}
}
