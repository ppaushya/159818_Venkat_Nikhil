package org.capg.service;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginService {
	
	public boolean isValidLogin(LoginBean loginBean);
	public boolean createCustomer(Customer customer);
	public boolean createaccount(Account acc,String mailid);
	public List<Account> getAllAccounts(String mailid);
	
}
