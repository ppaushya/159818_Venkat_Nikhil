package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
   PrintWriter out=response.getWriter();
   
   out.println("<!DOCTYPE html>\r\n" + 
   		"<html>\r\n" + 
   		"<head>\r\n" + 
   		"<meta charset=\"ISO-8859-1\">\r\n" + 
   		"<title>CapgBanking</title>\r\n" + 
   		"\r\n" + 
   		"<link type=\"text/css\" rel=\"stylesheet\" href=\"register.css\">\r\n" + 
   		"<script type=\"text/javascript\" src=\"pwvalidation.js\"></script>\r\n" + 
   		"\r\n" + 
   		"</head>\r\n" + 
   		"<body>\r\n" + 
   		"<form method=\"post\" action=\"register\" name=\"f2\" onsubmit=\"return validat()\" >\r\n" + 
   		"<div id=\"register\">\r\n" + 
   		"<h2 align=\"center\">Customer Registration Form</h2>\r\n" + 
   		"<hr>\r\n" + 
   		"	<div class=\"tablecnt\">\r\n" + 
   		"		<table >\r\n" + 
   		"			<tr>\r\n" + 
   		"				<th colspan=\"3\">Customer Form</th>\r\n" + 
   		"			</tr>\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>FirstName:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"text\" name=\"firstName\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>LastName:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"text\" name=\"lastName\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>DateOfBirth:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"date\" name=\"dateOfbirth\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>AddressLine1:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<textarea rows=\"3\" cols=\"25\" name=\"addressline1\"></textarea>\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>AddressLine2:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<textarea rows=\"3\" cols=\"25\" name=\"addressline2\"></textarea>\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>Choose City:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<select name=\"city\">\r\n" + 
   		"						<option value=\"Chennai\">Chennai</option>\r\n" + 
   		"						<option value=\"Hyderabad\">Hyderabad</option>\r\n" + 
   		"						<option value=\"Pune\">Pune</option>\r\n" + 
   		"						<option value=\"Delhi\">Delhi</option>\r\n" + 
   		"						<option value=\"Mumbai\">Mumbai</option>\r\n" + 
   		"						\r\n" + 
   		"					</select>\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>Choose State:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"radio\" name=\"state\" value=\"TamilNadu\"> TamilNadu\r\n" + 
   		"					<input type=\"radio\" name=\"state\" value=\"Andra\"> Andra \r\n" + 
   		"					<input type=\"radio\" name=\"state\" value=\"UP\"> UP \r\n" + 
   		"					<input type=\"radio\" name=\"state\" value=\"Maharashtra\"> Maharashtra \r\n" + 
   		"					 \r\n" + 
   		"					\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>Pincode:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"text\" name=\"pincode\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>EmailId:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"email\" name=\"email\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>MobileNumber:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"text\" name=\"mobile\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>Password:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"password\" name=\"custPwd\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"				<td>Confirm Password:</td>\r\n" + 
   		"				<td>\r\n" + 
   		"					<input type=\"password\" name=\"confimrCustPwd\" size=\"20\">\r\n" + 
   		"				</td>\r\n" + 
   		"				<td>\r\n" + 
   		"				<div id=\"passwordErrMsg\" class=\"pwerrMsg\"></div>\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"			\r\n" + 
   		"			<tr>\r\n" + 
   		"			\r\n" + 
   		"				<td></td>\r\n" + 
   		"				<td>\r\n" + 
   		"				\r\n" + 
   		"					<input type=\"submit\" name=\"register\" value=\"Register\" class=\"btnStyle\">\r\n" + 
   		"				</td>\r\n" + 
   		"			</tr>\r\n" + 
   		"			\r\n" + 
   		"		</table>\r\n" + 
   		"	\r\n" + 
   		"	</div>\r\n" + 
   		"</div>\r\n" + 
   		"</form>\r\n" );
   		
        HttpSession session=request.getSession();
        
   		if(session.getAttribute("check").toString().compareTo("true")==0)
   		{
   			out.println("<h3>Record succesfully inserted</h3>");
   		}
   		out.println("\r\n" + 
   		"</body>\r\n" + 
   		"</html>"
   		);
		
		
	}

	
}
