package org.sbi.dao;

import java.sql.Connection;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.sbi.model.Account;
import org.sbi.model.Customer;

public class CustomerDoaDbImpl implements ICustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		String sql="insert into customer(custid,firstname,lastname,emailid,mobileno) values(?,?,?,?,?)";
		
		try(Connection conn=getDbConnection()) {
			//	Statement statement=conn.createStatement();
				
				PreparedStatement statement=conn.prepareStatement(sql);
				statement.setInt(1, customer.getCustomerId());
				statement.setString(2, customer.getFirstName());
				statement.setString(3, customer.getLastName());
				statement.setString(4, customer.getEmailId());
				statement.setString(5, customer.getMobile());
				
				
				int count=statement.executeUpdate();
				
				if(count>0)
					System.out.println("Insertion done!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/customer", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	@Override
	public void createaccounts(Customer customer, Account account) {
		// TODO Auto-generated method stub
		
	}

}
