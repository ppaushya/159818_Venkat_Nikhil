package org.sbi.model;

public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD;

}
