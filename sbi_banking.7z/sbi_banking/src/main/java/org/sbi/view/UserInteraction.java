package org.sbi.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.sbi.model.Account;
import org.sbi.model.Address;
import org.sbi.model.Customer;
import org.sbi.util.Utility;

public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	
	
	
	
	public void printCustomers(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobile() );
		}
	}
	
	
	
	public Account getaccountdetails(Customer customer)
	{
		Account acc=new Account();
		
		System.out.println("enter the type of account you want to create");
		
		String type=scanner.next();
		
		Set<Account> accounts=customer.getAccounts();
		
		for(Account ac : accounts)
		{
			if(ac.getAccountType().compareTo(type)==0)
			{
				System.out.println("account already exists");
				return null;
			}
		}
		
		
	    acc.setAccountType(type);
	    acc.setAccountNumber(Utility.generateNumber());
	    acc.setDescription("this account is"+type);
	    acc.setOpeningBalance(1000);
	    acc.setOpeningDate(LocalDate.of(2000, 01, 01));

	    
		return acc;
	}
	
	
	
	
	
	
	
	
	
	
	
	public Customer getCustomerDetails() {
		
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setEmailId(promptEmailId());
		customer.setMobile(promptMobile());
		customer.setDateOfBirth(promptDateOfBirth());
		
		customer.setAddress(getAddressDetails());
		
		return customer;
	}
	
	public Customer findcustomer(List<Customer> customers)
	{
		System.out.println("enter the customer u want to choose");
		String temp=scanner.next();
		for(Customer cs : customers)
		{
			if(cs.getFirstName().compareTo(temp)==0)
			{
				return cs;
			}
		}
	return null;
	}
	
	public Customer fromcustomer(List<Customer> customers)
	{
		System.out.println("enter the customer u want to debit from");
		String temp=scanner.next();
		for(Customer cs : customers)
		{
			if(cs.getFirstName().compareTo(temp)==0)
			{
				return cs;
			}
		}
	return null;
	}
	
	
	public Customer tocustomer(List<Customer> customers)
	{
		System.out.println("enter the customer u want to credit to");
		String temp=scanner.next();
		for(Customer cs : customers)
		{
			if(cs.getFirstName().compareTo(temp)==0)
			{
				return cs;
			}
		}
	return null;
	}
	
	public Address getAddressDetails() {
		Address address=new Address();
		System.out.println("Enter AddressLine1:");
		address.setAddressLine1(scanner.next());
		System.out.println("Enter AddressLine2:");
		address.setAddressLine2(scanner.next());
		System.out.println("Enter City:");
		address.setCity(scanner.next());
		System.out.println("Enter State:");
		address.setState(scanner.next());
		address.setPincode(promptPincode());
		return address;
	}
	
	
	public String promptPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=scanner.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}

	public LocalDate promptDateOfBirth() {
		boolean flag=false;
		String dob;
		do {
			System.out.println("Enter DateOfBirth[dd-mm-yyyy]:");
			dob=scanner.next();
			flag=Utility.isValidDob(dob);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=dob.split("-");
		LocalDate date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return date;
	}
	
	public String promptMobile() {
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter mobile Number:");
			mobile=scanner.next();
			flag=Utility.isValidMobile(mobile);
			if(!flag)
				System.out.println("Please enter Valid 10 digit Mobile!");
		}while(!flag);
		
		return mobile;
	}
	
	public String promptFirstName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter FirstName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid FirstName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptLastName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter LastName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid LastName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptEmailId() {
		boolean flag=false;
		String email;
		do {
			System.out.println("Enter EmailId:");
			email=scanner.next();
			flag=Utility.isValidEmail(email);
			if(!flag)
				System.out.println("Please enter Valid EmailId!");
		}while(!flag);
		
		return email;
	}


	public void printError(String message) {
		System.out.println(message);
		
	}
	
	
}
