package org.sbi.boot;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.sbi.model.Account;
import org.sbi.model.Customer;
import org.sbi.services.CustomerServiceImpl;
import org.sbi.services.ICustomerService;
import org.sbi.view.UserInteraction;

public class BootClass {

	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		int  choice;
		String option;
		do {
		System.out.println("1.Create Customer");
		System.out.println("2.List Customers");
		System.out.println("3.create account");
		System.out.println("4.view accounts for a customer");
		System.out.println("5.withdrawal/deposit from a customer");
		System.out.println("6.do transaction between 2 customers");
		System.out.println("Enter Your choice:");
		choice=scanner.nextInt();
				
			switch(choice) {		
			case 1:
				
				int count=customerService.getAllCustomers().size();
				
				Customer customer=userInteraction.getCustomerDetails();
				customerService.createCustomer(customer);
				
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
					
				
				break;
			case 2:
				
				List<Customer> customers= customerService.getAllCustomers();
				userInteraction.printCustomers(customers);
				break;
			case 3 :
			          List<Customer> custs= customerService.getAllCustomers();
				Customer cust =userInteraction.findcustomer(custs);
				System.out.println(cust);
				if(cust!=null)
				{
					Account acc=userInteraction.getaccountdetails(cust);
					System.out.println(acc);
					
					customerService.createaccounts(cust,acc);
				}
				
			
				break;
			
			case 4 :
				 custs= customerService.getAllCustomers();
				 cust =userInteraction.findcustomer(custs);
				 Set<Account> accs=cust.getAccounts();
				 
				 for(Account ac:accs)
				 {
					 System.out.println(ac);
				 }
				 break;
			case 5 :
				custs= customerService.getAllCustomers();
				 cust =userInteraction.findcustomer(custs);
				 System.out.println("1.deposit");
				 System.out.println("2.withdrawal");
				 int k= scanner.nextInt();
				 if(k==1)
				 {
					 customerService.depositmoney(cust);
				 }
				 else
				 {
					 customerService.withdrawmoney(cust);
				 }
				break;
			case 6 :
				custs= customerService.getAllCustomers();
				 cust =userInteraction.fromcustomer(custs);
				 Customer cust1=userInteraction.tocustomer(custs);
				 customerService.dotransaction(cust,cust1);
				 
				break;
			default:
				System.out.println("Sorry! Invalid Choice");
				System.exit(0);
			
			}
			System.out.println("Do you wish to contine?[y|n]:");
			option=scanner.next();
			
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
		
		
		
		//System.out.println(customer);
	}

}

