package com.capgemini;


import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class soapclienttest {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub

		URL url=new URL("http://localhost:7709/ws/calculator?wsdl");
		
	QName qname=new QName("http://capgemini.com/", "calculatorimplService");
		
		Service service=Service.create(url,qname);
	
		Calculator calc=service.getPort(Calculator.class);
	
		System.out.println("add number method is "+calc.addnumber(10, 20));
	
		
		
	}

}
