package com.capgemini;

import javax.xml.ws.Endpoint;

public class calculatorpublisher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Endpoint.publish("http://localhost:7709/ws/calculator",new calculatorimpl());
	}

}
