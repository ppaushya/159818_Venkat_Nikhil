package org.cap.controller;

import javax.validation.Valid;

import org.cap.modal.Register;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {
	
	//@RequestMapping(value="/registerForm",method=RequestMethod.POST)
	@PostMapping("/registerForm")
	public String registerDetails(@Valid @ModelAttribute("register")Register register,
			BindingResult result)
	{
		if(result.hasErrors())
		{
			return "register";
		}
		else
			System.out.println("successs");
		return "success";
		
	}

}
