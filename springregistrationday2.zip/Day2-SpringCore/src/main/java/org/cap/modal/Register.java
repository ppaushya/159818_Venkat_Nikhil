package org.cap.modal;

import java.time.LocalDate;

import org.hibernate.validator.constraints.NotEmpty;

public class Register {
	
	@NotEmpty(message="Enter first Name")
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String gender;
	private String qualification;
	private LocalDate dateOfBirth;
	private String password;
	private String confirmpassword;
	public Register() {
		super();
	}
	public Register(String firstName, String lastName, String address, String city, String gender, String qualification,
			LocalDate dateOfBirth, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	@Override
	public String toString() {
		return "Register [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", city=" + city
				+ ", gender=" + gender + ", qualification=" + qualification + ", dateOfBirth=" + dateOfBirth
				+ ", password=" + password + ", confirmpassword=" + confirmpassword + "]";
	}
	
	

}
