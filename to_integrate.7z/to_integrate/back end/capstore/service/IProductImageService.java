package com.capstore.service;

public interface IProductImageService {

}
