import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MyordersComponent } from './myorders/myorders.component';
import { ReturngoodsComponent } from './returngoods/returngoods.component';
import { InitiatereturnComponent } from './initiatereturn/initiatereturn.component';
import { InvoiceComponent } from './invoice/invoice.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full',
  },
  {
    path: 'home',
    loadChildren: './home/home.module#HomeModule',
  },
  {
    path: 'chat',
    loadChildren: './chat/chat.module#ChatModule',
  },
  {
    path: 'products',
    loadChildren: './products/products.module#ProductsModule',
  },
  {
    path: 'bag',
    loadChildren: './bag/bag.module#BagModule',
  },
  {
    path: 'checkout',
    loadChildren: './checkout/checkout.module#CheckoutModule',
  },
  {
    path: 'auth',
    loadChildren: './auth/auth.module#AuthModule',
  },
  {
    path: 'payment',
    loadChildren: './payment/payment.module#PaymentModule',
  },
 
  {
    path : 'myorders',
    component : MyordersComponent,
  },
  {
    path : 'returngoods',
    component : ReturngoodsComponent,
  },
  {
    path : 'initiatereturn',
    loadChildren: './initiatereturn/initiatereturn.module#InitiatereturnModule',
  },
  {
    path : 'invoice',
    component: InvoiceComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
