import { Component } from '@angular/core';


@Component({
//   selector: 'forgot-password',
  templateUrl: './forgot-Password.component.html',
  styleUrls: ['./forgot-Password.component.css'],
})
export class ForgotPasswordComponent{

}