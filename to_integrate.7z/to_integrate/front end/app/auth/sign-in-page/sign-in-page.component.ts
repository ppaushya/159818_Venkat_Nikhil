import { Component, OnInit } from '@angular/core';
import { Login } from '../../models/login';
import { SignInPageService } from './sign-in-page.service';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-sign-in-page',
  templateUrl: './sign-in-page.component.html',
  styleUrls: ['./sign-in-page.component.scss']
})
export class SignInPageComponent implements OnInit {
  
  login:Login=new Login();
  message:string;
  validLogin:Login=new Login();
  invalid:boolean=false;
  validEmail:boolean=false;
  constructor(private _service:SignInPageService, private _router:Router) { }

  ngOnInit() {
  }

  validateLogin()
  {
    this._service.validateEmail(this.login).subscribe(
      validLogin=>{
        this.login=validLogin;
     
        /*
        if(validLogin.userTypes=="CUSTOMER")
      {
        this._router.navigate(['/home'])
      }
      else if(validLogin.userTypes=="MERCHANT")
      {
        this._router.navigate(['/merchant'])
      }
      else if(validLogin==null)
      {
        this._router.navigate(['/sign-in']);
        this.invalid=true;
        this.message="Invalid EmailId or Password";

      }
      */
     
     this._router.navigate(['/home'])

        
      }
    )
  }

  authenticatuser()
  {
    console.log("authenticateuser");
    if(this._service.validateEmail==null){
    this._service.authentication(1);
    }
    else{
      this._service.authentication(2);
    }
  }
}
