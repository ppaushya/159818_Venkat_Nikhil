import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Login } from '../../models/login';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SignInPageService {

  flag:boolean=true;
  login:Login[];
  loginUrl:string="http://localhost:8085/capstore/api/v1/validlogin";
  constructor(private _http:HttpClient) {}
  userauthentication:number=0;


  validateEmail(login:Login):Observable<Login>
  {
    console.log("service")
    return this._http.post<Login>(this.loginUrl,login)
    
  }

  authentication(value):number
  {
    this.userauthentication = value;
    return value;
  }

  userauthenticate():number
  {
    console.log(this.userauthentication);
    return this.userauthentication;
   
  }
  

}
