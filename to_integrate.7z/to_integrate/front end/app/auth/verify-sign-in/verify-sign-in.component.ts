import { Component, OnInit } from '@angular/core';
import { SignInPageService } from '../sign-in-page/sign-in-page.service';
import { Router } from '@angular/router';
import { Login } from '../../models/login';

@Component({
  selector: 'app-verify-sign-in',
  templateUrl: './verify-sign-in.component.html',
  styleUrls: ['./verify-sign-in.component.scss']
})
export class VerifySignInComponent implements OnInit {

    

  constructor() { }

  ngOnInit() {

   

    };

  }
