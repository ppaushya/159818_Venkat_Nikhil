
export class IInvoice {


invoiceNo: number;
order: IOrder;
discountedPrice: number;
discount: number;
InvoiceDate: String;
} 
 


export class IOrder{


    orderId:number;
    customer: ICustomer;
    cart:ICart;
   shipments:IShipment[];
    orderDate:string;

    }

    export class ICustomer{
        customerId:number;
        firstName:string;
        lastName:string;
        mobileNumber:string;
        emailId :string;
        addresses:Address[];
        isVerified:boolean;
        
        }  
            export class IProduct{
            
            productId:number;
            productName:string;
            productCategory:string;
            inventory:IInventory;
            productPrice:number;
            merchant:IMerchant;
            promo:IPromo;
            productsSold:number
            productView:number;
            isPromotionMessageSent:boolean;
            productDescription:string;
            quantity:number;
            discount:number;
            brand:string;

}


export class IInventory{

    inventoryId:number;
    merchant:IMerchant;
    productName:string;
    productCategory:string;
    productPrice:number;
    productDescription:string;
    promo:IPromo;
    status:string
    inventoryType:string
    inventoryQuantity:number
    
    }

    
export class IPromo{
    promoId:number;
    promoImageUrl:string;
    promoCode:string;
    discount:number;
    
    }

    export class IMerchant{

        merchantId:number;
        merchantName:string;
        emailId:string;
        merchantContact:string;
        merchantAddress:Address;
        isVerified:boolean
        }

        export class IShipment{

            shipmentId:number;
            address:Address;
            product:IProduct
            deliveryStatus:String;
            deliveryDate:string;
            dispatchDate:string;
            
            }

            export class ICart{
                cartId:number;
                customer:ICustomer
                minimumAmount:number;   
                cartProducts : ICartProduct[];             
                }

                export class ICartProduct{
                    serialNo:number;
                    customer:ICustomer;
                    product:IProduct;
                    quantity:number;
                    } 
                    export class Address{

                        addressId : number;
                        addressLine1: String;
                        addressLine2 : String;
                        city: String;
                        state:String;
                        pincode:number;
                        } 

                        export class Return
                        {
                            returnId : number;
                            order : IOrder;
                            product : IProduct;
                            pickupDate : String;
                            returnStatus : String; 
                        }

                        export class dummy
                        {
                            
                        }