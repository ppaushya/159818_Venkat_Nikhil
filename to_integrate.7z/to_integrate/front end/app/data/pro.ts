/*
export interface Pros {
    productid: number;
    productNmae: string;
    productDescription: string;
    productCategory: string;
    productImage: ProductPhoto[];
    productPrice: number;
    discount: number;
    productsSold:number;
    productView:number;
    isPromotionMessageSent:boolean;
    quantity:number;
    brand:number;
    Inventory:string;
    Promos:string;
  
  }
  export interface ProductPhoto {
    thumb: string;
    full: string;
    description: string;
  }
  */

 export interface MyProduct {
 productId:number;
 productName:string;
 productCategory:string,
     inventoryId:number;
 productPrice:number;
 promoId:number;
     productsSold:number;
 productView:number;
 isPromotionalMsg:boolean;
 productDescription:string;
 quantity:number;
 discount:number;
 brand:string;
 } 