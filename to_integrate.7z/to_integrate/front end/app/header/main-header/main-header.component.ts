import { Component, ElementRef, OnInit, Input } from '@angular/core';
import { Product } from '../../data/meta';
import { ProductService } from './main-header.service';
import { SignInPageService } from '../../auth/sign-in-page/sign-in-page.service';

@Component({
  selector: 'app-main-header',
  templateUrl: './main-header.component.html',
  styleUrls: ['./main-header.component.scss'],
})
export class MainHeaderComponent implements OnInit {
 // inputModel: any;

  displayMenu = false;

  menuAnchor: any;
  @Input()
  authenticated:boolean;
  
  _listFilter:string;
   //filteredProducts: IProduct[];
  products: Product[]=[]
  

  constructor(public el: ElementRef,private _productService: ProductService
    ,private signinservice:SignInPageService) {
  }

  ngOnInit() {
    this.menuAnchor = this.el.nativeElement;
    this.products= this._productService.getProducts();
  
  }
  get listFilter() :string{
    return this._listFilter;
}
set listFilter(value:string) {
    this._listFilter=value;

    this._productService.performFilter(this.listFilter);

}


authenticate(){
  console.log("in authenticate")
  if(this.signinservice.userauthenticate() == 1)
  {
    this.authenticated=false;
    console.log(this.authenticated);
  }
  else
  {
    this.authenticated=true;
  }
}



}
