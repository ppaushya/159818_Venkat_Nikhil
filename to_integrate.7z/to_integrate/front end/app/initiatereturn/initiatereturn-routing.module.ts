import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InitiatereturnComponent } from './initiatereturn.component';

const routes: Routes = [
{
  path: ':id',
  component: InitiatereturnComponent,
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InitiatereturnRoutingModule { }
