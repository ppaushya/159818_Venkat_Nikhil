import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InitiatereturnComponent } from './initiatereturn.component';

describe('InitiatereturnComponent', () => {
  let component: InitiatereturnComponent;
  let fixture: ComponentFixture<InitiatereturnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InitiatereturnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiatereturnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
