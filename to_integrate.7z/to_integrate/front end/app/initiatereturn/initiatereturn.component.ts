import { Component, OnInit, Input } from '@angular/core';
import { ReturngoodsService } from '../returngoods/returngoods.service';
import { InitiatereturnService } from './initiatereturn.service';
import { Observable } from 'rxjs';
import { dummy, Return } from '../data/orders';

@Component({
  selector: 'app-initiatereturn',
  templateUrl: './initiatereturn.component.html',
  styleUrls: ['./initiatereturn.component.scss']
})
export class InitiatereturnComponent implements OnInit {

  @Input() id:number;

  constructor(private returnservice: ReturngoodsService,private initiateservice : InitiatereturnService) { }

  ngOnInit() {
    this.id = this.returnservice.initiateidvalue();

    this.addrecordtoreturngoods();


  }


  part : Return;

  addrecordtoreturngoods() 
  {
    console.log("entered 1st stpe")
    this.initiateservice.addrecordtoreturngoods(this.id).subscribe();
  }


  checkstatus(tempnum : number)
  {
     console.log("check status entered component" + tempnum);
     this.initiateservice.checkstatus(tempnum).subscribe(temp=>this.part=temp); 



  }

  
  
  
  }


