import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InitiatereturnRoutingModule } from './initiatereturn-routing.module';
import { InitiatereturnComponent } from './initiatereturn.component';

@NgModule({
  declarations: [InitiatereturnComponent],
  imports: [
    CommonModule,
    InitiatereturnRoutingModule
  ]
})
export class InitiatereturnModule { }
