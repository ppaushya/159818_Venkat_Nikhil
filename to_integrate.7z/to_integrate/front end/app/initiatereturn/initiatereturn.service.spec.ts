import { TestBed } from '@angular/core/testing';

import { InitiatereturnService } from './initiatereturn.service';

describe('InitiatereturnService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InitiatereturnService = TestBed.get(InitiatereturnService);
    expect(service).toBeTruthy();
  });
});
