import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { dummy, Return } from '../data/orders';

@Injectable({
  providedIn: 'root'
})
export class InitiatereturnService {

  loginUrl:string="http://localhost:8087/capstore/api/v1/myorders/";
  loginUrl2:string="http://localhost:8087/capstore/api/v1/myorders/verify/";


  constructor(private _http:HttpClient) {}
  
  addrecordtoreturngoods(temp : number) : Observable<dummy>
  {
    console.log("entered my orders service" + temp);
    console.log(this.loginUrl+temp)
    return this._http.get<dummy>(this.loginUrl+temp)
  }

  checkstatus(temp : number): Observable<Return>
  {
    console.log("checking status in service " + temp);
    console.log(this.loginUrl2+temp);
    return this._http.get<Return>(this.loginUrl2+temp)

  }

  temppart : any;

}
