import { Component, OnInit } from '@angular/core';
import { MyOrdersService } from '../myorders/myorders.service';
import { Router } from '@angular/router';
import { IOrder, IInvoice } from '../data/orders';
import { InvoiceService } from './invoice.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit {

  constructor(private _service:InvoiceService, private _router:Router,private myordersservice:MyOrdersService) { }

  temporder : IOrder[];
  partInvoice: IInvoice;

  ngOnInit() {

 this.getInvoice(this.temporder);
 
 this.myordersservice.getallproductsdetails().subscribe(temp => this.temporder = temp)

  }

  getInvoice(temporder : IOrder[])
  {
    this._service.getInvoice(temporder).subscribe(temp => this.partInvoice = temp)
  }



}
