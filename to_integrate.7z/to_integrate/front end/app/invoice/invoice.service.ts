import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { IInvoice } from "../data/orders";

@Injectable({
providedIn: 'root'
})
export class InvoiceService {
//private _accountsUrl = "./api/account/accounts.json";
private _invoiceUrl = "http://localhost:8086/capstore/api/v1/getorders";

//change url
constructor(private _http: HttpClient){
}

getInvoice(temporder : any): Observable<IInvoice>{
    console.log("Service")
    console.log(temporder[0]+ " hii")
    return this._http.post<IInvoice>(this._invoiceUrl,temporder[0]);
    }
    } 