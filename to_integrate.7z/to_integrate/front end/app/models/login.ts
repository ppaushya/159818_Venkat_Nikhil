export class Login
{
    serialNo:number;
    emailId:string;
    password:string;
    userTypes:string;
}