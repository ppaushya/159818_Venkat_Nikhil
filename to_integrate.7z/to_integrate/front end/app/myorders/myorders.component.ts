import { Component, OnInit } from '@angular/core';
import { MyProduct } from '../data/pro';
import { RouterModule, Router } from '@angular/router';
import { MyOrdersService } from './myorders.service';
import { IOrder, Return } from '../data/orders';
import { InitiatereturnService } from '../initiatereturn/initiatereturn.service';


@Component({
  selector: 'app-myorders',
  templateUrl: './myorders.component.html',
  styleUrls: ['./myorders.component.scss']
})
export class MyordersComponent implements OnInit {

//error may raise
   order:IOrder[];
  
   constructor(private _service:MyOrdersService, private _router:Router) { }


  ngOnInit() {
    this.getallproductsdetails();

    this.getallreturnproducts();

  }
    
  getallproductsdetails()
  {
    this._service.getallproductsdetails().subscribe(temp => this.order = temp);
  }


  startreturngoods()
  {
    this._router.navigate(['/returngoods']);

  }

  returnproducts : Return[];

  getallreturnproducts()
  {
    this._service.getallreturnproducts().subscribe(temp => this.returnproducts = temp);
  }

}
