import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MyProduct } from '../data/pro';
import { IOrder, Return } from '../data/orders';

@Injectable({
  providedIn: 'root'
})
export class MyOrdersService {

 
  loginUrl:string="http://localhost:8087/capstore/api/v1/myorders";
  constructor(private _http:HttpClient) {}

  loginUrl3:string="http://localhost:8087/capstore/api/v1/getreturngoods";
   custid:number=100;
  


getallproductsdetails():Observable<IOrder[]>
{
    console.log("entered my orders service" + this.custid);
    return this._http.get<IOrder[]>(this.loginUrl)
}


getallreturnproducts() : Observable<Return[]>
{
       return this._http.get<Return[]>(this.loginUrl3);
}

}
