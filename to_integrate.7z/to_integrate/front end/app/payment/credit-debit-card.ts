export class CreditDebitCard {
    cardNumber: string;
    cardHolderName: string;
    expiryDate: string;
    cvv: number;
    pin: number;
    balance: number;
    pinNumber: number;
}