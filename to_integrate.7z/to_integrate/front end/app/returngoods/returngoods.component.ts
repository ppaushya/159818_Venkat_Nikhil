import { Component, OnInit } from '@angular/core';
import { MyOrdersService } from '../myorders/myorders.service';
import { Router } from '@angular/router';
import { IOrder } from '../data/orders';
import { ReturngoodsService } from './returngoods.service';

@Component({
  selector: 'app-returngoods',
  templateUrl: './returngoods.component.html',
  styleUrls: ['./returngoods.component.scss']
})
export class ReturngoodsComponent implements OnInit {

  constructor(private _service:MyOrdersService, private _router:Router
    ,private returngoodsservice : ReturngoodsService) { }
  
  ordertemp:IOrder[];

   iddata: number;
  ngOnInit() {
   
    this._service.getallproductsdetails().subscribe(temp => this.ordertemp = temp);
  
  }


  areyousuretoreturn(id : any)
  {
    this.iddata=id;
    console.log(id + "printing ids");
    this._router.navigate(['/initiatereturn/',id]);
  }
  

  sendiddata()
  {
    this.returngoodsservice.sendiddata(this.iddata);
  }

}
