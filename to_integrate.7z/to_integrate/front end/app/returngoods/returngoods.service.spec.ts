import { TestBed } from '@angular/core/testing';

import { ReturngoodsService } from './returngoods.service';

describe('ReturngoodsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReturngoodsService = TestBed.get(ReturngoodsService);
    expect(service).toBeTruthy();
  });
});
