import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReturngoodsService {

  iddata: number;
  constructor() { }
 
  sendiddata(sendiddata : number) 
  {
      this.iddata = sendiddata;
  }

  initiateidvalue():number
  {
      return this.iddata;
  }


}
