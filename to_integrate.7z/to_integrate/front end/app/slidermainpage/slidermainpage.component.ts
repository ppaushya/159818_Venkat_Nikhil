import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slidermainpage',
  templateUrl: './slidermainpage.component.html',
  styleUrls: ['./slidermainpage.component.css']
})
export class SlidermainpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
