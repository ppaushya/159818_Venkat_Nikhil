export interface UiPhotoCarouselPhoto {
  full: string;
  thumb: string;
  description: string;
}
