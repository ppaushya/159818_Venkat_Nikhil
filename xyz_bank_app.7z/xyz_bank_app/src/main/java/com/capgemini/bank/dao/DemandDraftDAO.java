package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {

	final static Logger logger=Logger.getLogger(DemandDraftDAO.class);
	
	@Override
	public int addDemandDraftDetails(DemandDraft newDemand) {
		// TODO Auto-generated method stub
		//sql statements
		
		String sql="insert into demand_draft(customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description) values(?,?,?,?,?,?,?)";
		String sql1="select * from demand_draft";
		try(Connection conn=getDbConnection())
		{
			
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			
			
			pst.setString(1, newDemand.getCustomer_name());
			pst.setString(2, newDemand.getIn_favor_of());
			pst.setString(3, newDemand.getPhone_number());
			pst.setDate(4, Date.valueOf(newDemand.getDate_of_transaction()));
			pst.setDouble(5, newDemand.getDd_amount());
			pst.setDouble(6, newDemand.getCommission_number());
			pst.setString(7, newDemand.getDescription());
			
			
			int count=pst.executeUpdate();
			
		   if(count>=1)
		   {
			   //System.out.println("insertion done");
			   
			   java.sql.PreparedStatement pst1=conn.prepareStatement(sql1);
			     
			   ResultSet res=pst1.executeQuery();
			   
			   while(res.next())
			   {
				   if(res.getString(2).compareTo(newDemand.getCustomer_name())==0 && res.getString(3).compareTo(newDemand.getIn_favor_of())==0 && res.getString(4).compareTo(newDemand.getPhone_number())==0 && res.getDouble(6)==newDemand.getDd_amount())  
				   {
					   return res.getInt(1);
				   }
			   }
		   }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("sql exception");
			//e.printStackTrace();
		}
		return 0;
		
	}
	
	

	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			logger.error("class not found exception and sql exception occured");
			//e.printStackTrace();
		}
		
		return null;
		
	}



	@Override
	public DemandDraft getDemandDraftDetails(int trans_id) {
		// TODO Auto-generated method stub
		logger.info("successfully registered");
		System.out.println("Your Demand Draft request has been successfully registered along with the "+trans_id);
		return null;
	}	

}
