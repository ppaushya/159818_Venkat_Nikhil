package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO {

	public int addDemandDraftDetails(DemandDraft newDemand);

	public DemandDraft getDemandDraftDetails(int trans_id);

}
