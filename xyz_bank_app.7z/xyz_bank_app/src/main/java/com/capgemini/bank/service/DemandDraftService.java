package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO demandraftdao = new DemandDraftDAO();
	
	public DemandDraftService(IDemandDraftDAO demanddraftdao) {
		// TODO Auto-generated constructor stub
		
		this.demandraftdao=demanddraftdao;
	}

	public DemandDraftService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int addDemandDraftDetails(DemandDraft newDemand) throws InvalidAmountException  {
		// TODO Auto-generated method stub
		
		//if it is valid demand draft it gets added else an custom exception rises
		if(validDemandDraft(newDemand))
		{
			return demandraftdao.addDemandDraftDetails(newDemand);
		}
		else
		{
		  	throw new InvalidAmountException("amount cannot be negative..pls check and insert the details again");
		}
		
		
	}

	private boolean validDemandDraft(DemandDraft newDemand) {
		// TODO Auto-generated method stub
		
		if(newDemand.getDd_amount()<0)
		{
			System.out.println("amount cannot be negative");
			return false;
		}
		
		return true;
	}

	@Override
	public void getDemandDraftDetails(int trans_id) {
		// TODO Auto-generated method stub
		demandraftdao.getDemandDraftDetails(trans_id);
	}

	
	
	
}
