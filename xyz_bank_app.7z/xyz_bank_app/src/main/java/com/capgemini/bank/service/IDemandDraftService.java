package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {

	public int addDemandDraftDetails(DemandDraft newDemand) throws InvalidAmountException;

	public void getDemandDraftDetails(int trans_id);

	
	
	
}
