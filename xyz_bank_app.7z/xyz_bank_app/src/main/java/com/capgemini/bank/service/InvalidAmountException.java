package com.capgemini.bank.service;

public class InvalidAmountException extends Exception {

	public InvalidAmountException(String str)
	{
		super(str);
	}
	
}
