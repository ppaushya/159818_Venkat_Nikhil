package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.service.InvalidAmountException;

public class Client {

	static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) throws InvalidAmountException {
		// TODO Auto-generated method stub
        Client obj=new Client();
        
        IDemandDraftService demandraftservice = new DemandDraftService();
		
		boolean flag=true;
		
		
		/*
		 * initially we wont have any table..so we will get an error ..so we should create a table and 
		 * i have attached that sql file in both (src/main/resources) and a seperate notepad file..and 
		 * we have to create mydb database 
		 * 
		 * 
		 */
		
		while(true)
		{
			System.out.println("1.Enter the demand draft details");
			System.out.println("2.Exit");
			int choice=scanner.nextInt();
			
			if(choice==1)
			{
				DemandDraft newDemand=obj.promptDemandDraftDetails();
				int trans_id=demandraftservice.addDemandDraftDetails(newDemand);
				demandraftservice.getDemandDraftDetails(trans_id);
			}
			else if(choice==2)
			{
				//will be termianted from program
				System.exit(0);
			}
		}
		
		
	}

	private DemandDraft promptDemandDraftDetails() {
		// TODO Auto-generated method stub
	DemandDraft draft=new DemandDraft();
	
	//setting customer name
	
	draft.setCustomer_name(promptcustomername());
	
	//setting in favor of
	
	draft.setIn_favor_of(promptinfavorof());
	
	//setting mobile number
	
	draft.setPhone_number(promptphonenumber());
	
	//setting date of transaction
	
	draft.setDate_of_transaction(promptdateoftransaction());
	
	//setting dd amount
	
	draft.setDd_amount(promptddamount());
	
	//setting commission
	
	draft.setCommission_number(promptcommnumber(draft.getDd_amount()));
	
	//setting description
	
	draft.setDescription(promptdescription());
	
	return draft;
	
	}

	private String promptdescription() {
		// TODO Auto-generated method stub
		
		String str;
		
		System.out.println("Enter the description");
		
		str=scanner.next();
		
		return str;
		
	}

	private double promptcommnumber(double dd_amount) {
		// TODO Auto-generated method stub
		
		
		if(dd_amount<=5000)
		{
			return (10+dd_amount);
		}
		else if(dd_amount>5000 && dd_amount<=10000)
		{
			return (41+dd_amount);
		}
		else if(dd_amount>10000 && dd_amount<=100000)
		{
			return (51+dd_amount);
		}
		else
		{
			return (306+dd_amount);
		}
		
		
	}

	private double promptddamount() {
		// TODO Auto-generated method stub
		
		double amount;
		  
		   System.out.println("Enter the dd amount");
		   
		   amount=scanner.nextDouble();
			
			return amount;
		
		
	}

	private LocalDate promptdateoftransaction() {
		// TODO Auto-generated method stub
		
		String str;
		boolean flag=true;
		
		while(flag)
		{
		System.out.println("Enter the date of transaction in the format[dd-mm-yyyy]");
		
		str=scanner.next();
		
		String datesplit[]=str.split("-");
		
		flag=false;
		if(Integer.parseInt(datesplit[2])>999 && Integer.parseInt(datesplit[1])>0 && Integer.parseInt(datesplit[1])<=12 && Integer.parseInt(datesplit[0])>0 && Integer.parseInt(datesplit[0])<=31)
		{
		return LocalDate.of(Integer.parseInt(datesplit[2]), Integer.parseInt(datesplit[1]), Integer.parseInt(datesplit[0]));
		
		}
		else
		{
			System.out.println("date of transaction should be in proper format");
			flag=true;
		}
		
		}
		return null;
	}

	private String promptphonenumber() {
		// TODO Auto-generated method stub
	boolean flag=true;
		
		String mobileNo;
		
	 while(flag)
	 {
		System.out.println("Enter the mobile no of the customer :");
	
		mobileNo=scanner.next();
		
		if(mobileNo.matches("(7|8|9){1}[0-9]{9}"))
		{
			flag=false;
			return mobileNo;
		}
		else
		{
			flag=true;
			System.out.println("mobile no should be in numericals and 10 digits and should start with 7 or 8 or 9..so enter one more time");
		}
	}
		
		
		return null;
	}

	private String promptinfavorof() {
		// TODO Auto-generated method stub
		

		boolean flag=true;
		
		String inFavorOf;
		
	 while(flag)
	 {
		System.out.println("Enter the dd recipient (only alphabets) :");
	
		inFavorOf=scanner.next();
		
		if(inFavorOf.matches("[A-Za-z]+"))
		{
			flag=false;
			return inFavorOf;
		}
		else
		{
			flag=true;
			System.out.println("in favor of should be in alphabeticals only..enter one more time");
		}
	}
		
		
		return null;
	}

	private String promptcustomername() {
		// TODO Auto-generated method stub
	
		boolean flag=true;
		
		String custName;
		
	 while(flag)
	 {
		System.out.println("Enter the name of the customer :");
	
		custName=scanner.next();
		
		if(custName.matches("[A-Za-z]+"))
		{
			//flag=false;
			return custName;
		}
		else
		{
			flag=true;
			System.out.println("Name should be in alphabeticals only..enter one more time");
		}
	}

	 return null;
}
}
