package xyz_bank_app;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.service.InvalidAmountException;

public class TestBankingApplication {

	
	@Mock
	private IDemandDraftDAO demanddraftdao;
	private IDemandDraftService demanddraftservice;
	
	
	@Before
	public void setup()
	{
        //initialising the objects
		MockitoAnnotations.initMocks(this);
		demanddraftservice = new DemandDraftService(demanddraftdao);
	}
	
	
	
	@Test
	public void test_account_with_correct_details()
	{
	    DemandDraft demanddraft=new DemandDraft();
	    demanddraft.setCustomer_name("nikhilll");
	    demanddraft.setIn_favor_of("capgemini");
	    demanddraft.setDd_amount(100);
	    demanddraft.setDescription("draft");
	    demanddraft.setDate_of_transaction(LocalDate.of(2000, 10, 10));
	    demanddraft.setCommission_number(100);
	    demanddraft.setPhone_number("7989499127");
	   
	    //dummy declaration
	    
	    Mockito.when(demanddraftdao.addDemandDraftDetails(demanddraft)).thenReturn(1);
	    
	    //triggering the actual logic
	    try {
			demanddraftservice.addDemandDraftDetails(demanddraft);
		} catch (InvalidAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    //verifying mockito
	    
	    Mockito.verify(demanddraftdao).addDemandDraftDetails(demanddraft);
	    
	    
	}
	
	
	
	
	
}
