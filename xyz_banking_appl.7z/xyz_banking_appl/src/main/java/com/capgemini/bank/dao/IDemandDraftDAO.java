package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO {


	public int addDemandDraftDetails(DemandDraft demanddraft);
	public DemandDraft getDemandDraftDetails(int transaction_id); 
	
}
