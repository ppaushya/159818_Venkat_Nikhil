package com.capgemini.bank.service;

import org.apache.log4j.*;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exceptions.InvalidAmountException;

public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO demanddraftDao=new DemandDraftDAO(); 
	
	final static Logger logger=Logger.getLogger(DemandDraftService.class);
	
	public DemandDraftService(IDemandDraftDAO demanddraftdao2) {
		// TODO Auto-generated constructor stub
		this.demanddraftDao=demanddraftdao2;
	}

	public DemandDraftService() {
		// TODO Auto-generated constructor stub
	}

	public int addDemandDraftDetails(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		
		
		try {
			if(validdemanddraft(demanddraft))
			{
			return demanddraftDao.addDemandDraftDetails(demanddraft);
			}
			else
			{
				logger.error("this is log error");
				throw new InvalidAmountException("amount cannot be 0 or negative");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return 2;
		
	}

	private boolean validdemanddraft(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		
		if(demanddraft.getDd_amount()>0)
		{
			return true;
		}
		
		return false;
	}

	public DemandDraft getDemandDraftDetails(int transaction_id) {
		// TODO Auto-generated method stub
		return demanddraftDao.getDemandDraftDetails(transaction_id);
	}

}
