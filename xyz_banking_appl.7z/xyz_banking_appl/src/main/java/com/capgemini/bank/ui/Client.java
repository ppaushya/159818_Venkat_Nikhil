package com.capgemini.bank.ui;

import java.beans.Customizer;
import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	static Scanner scanner=new Scanner(System.in);
	
	public DemandDraft getDemandDraft()
	{
		
		DemandDraft demanddraft=new DemandDraft();
		
	    demanddraft.setCustomer_name(promptcustomername());
	   
	    
	    demanddraft.setIn_favor_of(promptinfavorof());
	    
	    
	    
	    demanddraft.setPhone_number(promptphonenumber());
	    

	    
	    demanddraft.setDate_of_transaction(promptdateoftrans());
	    
		demanddraft.setDd_amount(promptddamount());
		
		demanddraft.setDd_description(promptdddescription());
		
		demanddraft.setDd_commission(promptddcalculate(demanddraft.getDd_amount()));
		
		
		
		return demanddraft;
	}
	
	
	
	private double promptddcalculate(double dd_amount) {
		// TODO Auto-generated method stub
		
		if(dd_amount<=5000)
		{
			return (10+dd_amount);
		}
		else if(dd_amount>5000 && dd_amount<=10000)
		{
			return (41+dd_amount);
		}
		else if(dd_amount>10000 && dd_amount<=100000)
		{
			return (51+dd_amount);
		}
		else
		{
			return (306+dd_amount);
		}
		
	}



	private String promptdddescription() {
		// TODO Auto-generated method stub
		System.out.println("Enter the dd description");
		String str=scanner.next();
		
		return str;
	}



	private double promptddamount() {
		// TODO Auto-generated method stub
		
	   double amount;
	  
	   System.out.println("Enter the dd amount");
	   
	   amount=scanner.nextDouble();
	   
	   
		
		return amount;
	}



	private LocalDate promptdateoftrans() {
		// TODO Auto-generated method stub
		System.out.println("enter the date of transaction[dd-mm-yyyy]");
		
		String dateoftrans=scanner.next();
		
		String date1[]=dateoftrans.split("-");
		
		return LocalDate.of(Integer.parseInt(date1[2]), Integer.parseInt(date1[1]), Integer.parseInt(date1[0]));
	
	}



	private String promptphonenumber() {
		// TODO Auto-generated method stub
		boolean flag=true;
		String mobileno;
		do
		{
		System.out.println("Enter the mobile no of the customer");
		
		 mobileno=scanner.next();
		
		if(!mobileno.matches("(7|8|9){1}[0-9]{9}"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return mobileno;
	}



	private String promptinfavorof() {
		// TODO Auto-generated method stub
		boolean flag=true;
		String infavorof;
		do
		{
		System.out.println("Enter the dd reciepent");
		
		 infavorof=scanner.next();
		
		if(!infavorof.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return infavorof;
	}



	private String promptcustomername() {
		// TODO Auto-generated method stub
		boolean flag=true;
		String custName;
		do
		{
		System.out.println("Enter the name of the customer");
		
		 custName=scanner.next();
		
		if(!custName.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return custName;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Client obj=new Client();
		
		IDemandDraftService ddservice = new DemandDraftService();
		
		while(true)
		{
			System.out.println("1.enter demand draft details");
			System.out.println("2.exit");
			int ch=scanner.nextInt();
			
			
			if(ch==1)
			{
				DemandDraft newDraft= obj.getDemandDraft();
				int count=ddservice.addDemandDraftDetails(newDraft);
				//System.out.println("count is "+count);
				ddservice.getDemandDraftDetails(count);
				}
		}
		
		
	}

}
